<?php $__env->startSection('script1'); ?>
<link rel="stylesheet" type="text/css" href="css/jquery.dataTables.min.css">
<link rel="stylesheet" type="text/css" href="css/select.dataTables.min.css">
<script type="text/javascript" src="js/jquery.min.js"></script>
<script type="text/javascript" src="js/jquery.dataTables.min.js"></script>
<script type="text/javascript" src="js/dataTables.select.min.js"></script>
<script type="text/javascript">
         $(document).ready(function() {
    $('#table-general').DataTable( {

    "fixedHeader":    true,
    "bInfo" :         false,
    "bSortable":      false,
    searching:        false,
    paging:           false,
    fixedColumns: {
        leftColumns: 1,
        rightColumns: 1
    },
    columnDefs: [ {
        orderable: false,
        //className: 'select-checkbox',
        targets:   0
    } ],
    select: {
        style:    'multi',
        selector: 'td:first-child'
    },
    order: [[ 1, 'asc' ]]
 
 
});
//       var  DT1 = $('#table-general').DataTable();
// $(".selectAll").on( "click", function(e) {
//     if ($(this).is( ":checked" )) {
//         DT1.rows(  ).select();        
//     } else {
//         DT1.rows(  ).deselect(); 
//     }
// });

} );
      </script>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
	<?php $__env->startSection('header'); ?>
		##parent-placeholder-594fd1615a341c77829e83ed988f137e1ba96231##
	<?php $__env->stopSection(); ?>

	<?php $__env->startSection('sidebar'); ?>
		##parent-placeholder-19bd1503d9bad449304cc6b4e977b74bac6cc771##
	<?php $__env->stopSection(); ?> 
    
         <div class="content-wrapper">
            <div class="background-transperent">
               <section class="content-header">
                  <div class="container-fluid">
                     <div class="row">
                        <div class="col-md-3 page-background">
                           <h1 class="page-title listing-dropdown">
                           	
                           	Ethnicities

                           </h1>
                        </div>
                        <div class="col-md-6"></div>
                        <div class="col-md-3" id="header-btn-section">
                          <ul class="new-dropdown-hover">
                            <li class="droupdown-hover-add">
                              <a href="<?php echo e(route('ethnicity-add')); ?>" class="btn btn-info" id="header-new-btn">New</a>    
                            </li>
                            <!--
                            <li>
                              <button type="button" class="btn" id="header-search-btn"><i class="fa fa-search" aria-hidden="true"></i></button>
                            </li>
                            -->
                          </ul>
                        </div>
                  </div>
               </section>
               <section class="content" id="user-listing-section">
                  <div class="container-fluid">
                     <div class="row">
                        <div class="col-md-12 consumer-section">
                                <table id="table-general" class="display user-table" style="width:100%">
                                   <thead>
                                       <tr>
                                           
                                           <th>Title</th>
                                           
                                           
                                       </tr>
                                   </thead>
                                <tbody>
                                <?php if(count($ethnicities) > 0): ?>
                                    <?php $__currentLoopData = $ethnicities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ethnicity): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                        <tr>
                                           
                                            <td><a href="<?php echo e(route('ethnicity-edit', $ethnicity->id)); ?>" class="name-class"><?php echo e($ethnicity->title); ?></a></td>
                                            
                                            
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php else: ?>
                                    <tr>
                                           
                                        <td colspan="2" align="center">No Records!</td>
                                        
                                        
                                    </tr>
                                <?php endif; ?>

                                    
                            </table>
                        </div>
                     </div>
                  </div>
               </section>
            </div>
         </div>
      </div>



<?php $__env->stopSection(); ?>
<?php $__env->startSection('script2'); ?>
<script type="text/javascript">
   // Tabs Show JS
   function openTabs(evt, tabsName) {
     var i, contentsection, tabs;
     contentsection = document.getElementsByClassName("contentsection");
     for (i = 0; i < contentsection.length; i++) {
       contentsection[i].style.display = "none";
     }
     tabs = document.getElementsByClassName("tabs");
     for (i = 0; i < tabs.length; i++) {
       tabs[i].className = tabs[i].className.replace(" active", "");
     }
     document.getElementById(tabsName).style.display = "block";
     evt.currentTarget.className += " active";
   }

   // Tabs active js
   $('.nav-tabs').on('click', 'li', function() {
    $('.nav-tabs li.active-tabs').removeClass('active-tabs');
       $(this).addClass('active-tabs');
   });

   // Sidebar active menu js
   $('.nav-sidebar').on('click', 'li', function() {
    $('.nav-sidebar li.active-menu').removeClass('active-menu');
       $(this).addClass('active-menu');
   });

   // Mobile Menu active Js
   function myFunction() {
     var x = document.getElementById("sidebar");
     if (x.className === "main-sidebar") {
       x.className += " sidebar-hide";
     } else {
       x.className = "main-sidebar";
     }
   }

   $('#user-add-icon').click(function(){
      $("#drop-down-profile").toggleClass('show');
   });

    $('#user-mobile-icon').click(function(){
      $("#mobile-dropdown").toggleClass('show-add');
   });
    
</script>
<style>
table#table-general tr td,table#table-general tr th{padding: 8px;}
</style>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp\www\laravel\laravel8\focuspoint\resources\views/ethnicity/ethnicity-listing.blade.php ENDPATH**/ ?>