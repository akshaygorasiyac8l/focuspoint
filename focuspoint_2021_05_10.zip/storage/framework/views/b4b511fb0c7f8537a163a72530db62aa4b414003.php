<?php $__env->startSection('title', 'Home'); ?>
<?php $__env->startSection('script1'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
         <div class="content-wrapper">
            <form id="profile-form" action="<?php echo e(route('profile')); ?>" method="POST">
            <?php echo csrf_field(); ?>
            
            
            


               <div class="background-transperent">
               
                  <section class="content" id="profile-add">
                     
                     <?php if(count($errors) > 0): ?>
                         <div class="alert alert-danger">
                             <ul>
                                 <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                     <li><?php echo e($error); ?></li>
                                 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                             </ul>
                         </div>
                      <?php endif; ?>
                      
                      <div class="container-fluid">
                        <div class="row">
                           <div class="col-md-8 consumer-section">
                              <div class="card card-primary">
                                 
                                    <div class="card-body">
                                       <div class="form-group row">
                                          <label for="inputEmail3" class="col-md-3 col-form-label">Full Name</label>
                                          <div class="col-md-9">
                                             <div class="row salutions">
                                                <div class="col-md-3 short-col">
                                                   <select class="form-control droupdown mobile-drop" name="salution">
                                                   <option value="">Salutation</option>
                                                   <option <?php if($user->salution=='Mr') { echo "selected";}?> value="Mr">Mr.</option>
                                                   <option <?php if($user->salution=='Mrs') { echo "selected";}?> value="Mrs">Mrs.</option>
                                                   <option <?php if($user->salution=='Ms') { echo "selected";}?> value="Ms">Ms.</option>
                                                   <option <?php if($user->salution=='Miss') { echo "selected";}?> value="Miss">Miss.</option>
                                                   <option <?php if($user->salution=='Dr') { echo "selected";}?> value="Dr">Dr.</option>
                                                </select>                                             
                                                </div>
                                                <div class="col-md-4">
                                                   <input type="text" class="form-control mobile-drop" placeholder="First Name" name="fname" value="<?php echo e($user->fname); ?>">
                                                </div>
                                                <div class="col-md-4">
                                                   <input type="text" class="form-control mobile-drop"  placeholder="Last Name" name="lname" value="<?php echo e($user->lname); ?>">
                                                </div>
                                                <div class="col-md-1"></div>
                                             </div>
                                          </div>
                                       </div>
                                       <div class="form-group row">
                                          <label for="inputPassword3" class="col-md-3 col-form-label">Login</label>
                                          <div class="col-md-9 time-add">
                                             <select class="form-control droupdown width-add" name="login">
                                                <option value="">Select</option>
                                                <option value="1">Login 1</option>
                                                <option value="2">Login 1</option>
                                             </select>
                                          </div>
                                       </div>
                                       <!-- <div class="form-group row">
                                          <label for="inputPassword3" class="col-md-3 col-form-label">Avatar</label>
                                          <div class="col-md-9 time-add">
                                             <input type="text" class="form-control width-add" name="avatar" placeholder="">
                                          </div>
                                       </div> -->
                                       <div class="form-group row">
                                          <label for="inputPassword3" class="col-md-3 col-form-label">Email Address</label>
                                          <div class="col-md-9 time-add">
                                             <input type="email" class="form-control width-add" name="email" placeholder="" value="<?php echo e($user->email); ?>">
                                          </div>
                                       </div>
                                       <div class="form-group row">
                                          <label for="inputPassword3" class="col-md-3 col-form-label">Local Time Zone</label>
                                          <div class="col-md-9">
                                             <div class="row salutions">
                                                <div class="col-md-3 country-add">
                                                   <input type="text" class="form-control mobile-drop" name="country" placeholder="Country" value="<?php echo e($user->country); ?>">
                                                </div>
                                                <div class="col-md-8 short-col">
                                                   <input type="text" class="form-control mobile-drop" name="time"  placeholder="Thursday, 11 March 2021" value="<?php echo e($user->time); ?>">
                                                </div>
                                             </div>
                                          </div>
                                       </div>
                                    </div>
                                 
                              </div>
                           </div>
                           <div class="col-md-4"></div>
                        </div>
                     </div>
                  </section>
                  <section class="footer-section">
                     <div class="container-fluid">
                        <div class="card-footer">
                           <button type="submit" name="save" class="btn btn-info">Save</button>
                           <button type="submit" class="btn btn-default float-right">Cancel</button>
                         </div>
                     </div>
                  </section>
               </div>
            </form>
         </div>

<?php $__env->stopSection(); ?>


<?php $__env->startSection('script2'); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp\www\laravel\laravel8\focuspoint\resources\views/profile.blade.php ENDPATH**/ ?>