<?php $__env->startSection('script1'); ?>
<link rel="stylesheet" type="text/css" href="css/jquery-ui-timepicker-addon.css">
      <link rel="stylesheet" type="text/css" href="css/jquery.dataTables.min.css">
      <link rel="stylesheet" type="text/css" href="css/select.dataTables.min.css">
      <link rel="stylesheet" type="text/css" href="css/bootstrap-datetimepicker.css">
      <!-- <script type="text/javascript" src="js/jquery.min.js"></script> -->
      <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/jquery/2.2.0/jquery.min.js"></script>
      <script src="http://code.jquery.com/ui/1.11.0/jquery-ui.js"></script>
      <script type="text/javascript" src="js/jquery.validate.min.js"></script>
      <script type="text/javascript" src="js/app.js"></script>
      <script type="text/javascript" src="js/bootstrap.min.js"></script>
      <script type="text/javascript" src="js/jquery.dataTables.min.js"></script>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
	<?php $__env->startSection('header'); ?>
		##parent-placeholder-594fd1615a341c77829e83ed988f137e1ba96231##
	<?php $__env->stopSection(); ?>

	<?php $__env->startSection('sidebar'); ?>
		##parent-placeholder-19bd1503d9bad449304cc6b4e977b74bac6cc771##
	<?php $__env->stopSection(); ?> 
    
         <div class="content-wrapper">
            <form id="form-consumer" name="employee-form" action="" method="POST">
            <?php echo csrf_field(); ?>
               <div class="background-transperent">
                  <section class="content-header">
                     <div class="container-fluid">
                        <div class="row">
                           <div class="col-md-12 page-background">
                              <h1 class="page-title">Edit Certfication Type</h1>
                           </div>
                        </div>
                     </div>
                  </section>
                  <section class="content">
                     <div class="container-fluid">
                        <div class="row">
                           <div class="col-md-8 consumer-section">
                              <div class="card card-primary">
                                 <div class="card-body">
            
                                 <div class="form-group row">
                                    <label class="col-md-3 col-form-label">Certfication Type</label>
                                    <div class="col-md-9">
                                       <div class="row">
                                          <div class="col-md-12 time-add">
                                             <input type="text" name="title" class="form-control "  placeholder="Certfication Type" value="<?php echo e($certfication_type->title); ?>" required>
                                          </div>
                                          
                                       </div>                                             
                                    </div>
                                 </div>
                                    
                                 
                                    
                                    
                                    
                             
                                 
                                 </div>
                              </div>
                           </div>
                           <div class="col-md-4">
                           </div>
                        </div>
                     </div>
                  </section>
       
                  
                  <section class="footer-section">
                     <div class="container-fluid">
                        <div class="card-footer">
                           <button type="submit" class="btn btn-info" name="save">Save</button>
                           <a href="<?php echo e(route('certificate-types')); ?>" class="btn btn-default float-right">Cancel</a>
                         </div>
                     </div>
                  </section>
               </div>
            </form>
         </div>

   

<?php $__env->stopSection(); ?>
<?php $__env->startSection('script2'); ?>
<script src="https://trentrichardson.com/examples/timepicker/jquery-ui-timepicker-addon.js"></script>
<script type="text/javascript" src="js/moment.min.js"></script>
<script type="text/javascript" src="js/angular.min.js"></script>
<script type="text/javascript" src="js/bootstrap-datetimepicker.min.js"></script>
<script type="text/javascript">
   $('.nav-sidebar').on('click', 'li', function() {
     $('.nav-sidebar li.active-menu').removeClass('active-menu');
     $(this).addClass('active-menu');
   });
</script>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp\www\laravel\laravel8\focuspoint\resources\views/certificate/certificate-type-edit.blade.php ENDPATH**/ ?>