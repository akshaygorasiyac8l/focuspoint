<?php

use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});

Auth::routes();

Route::get('/home', [App\Http\Controllers\HomeController::class, 'index'])->name('home');
Route::any('/profile', [App\Http\Controllers\GeneralController::class, 'profile'])->name('profile');


Route::get('/consumers-listing', [App\Http\Controllers\ConsumerController::class, 'index'])->name('consumers-listing');
Route::get('/consumers-add', [App\Http\Controllers\ConsumerController::class, 'addConsumer'])->name('consumers-add');
Route::get('/consumers-details', [App\Http\Controllers\ConsumerController::class, 'consumerDetail'])->name('consumers-details');


Route::get('/assessments-listing', [App\Http\Controllers\AssessmentController::class, 'index'])->name('assessments-listing');
Route::get('/assessments-add', [App\Http\Controllers\AssessmentController::class, 'addAssessment'])->name('assessments-add');
Route::get('/assessments-details', [App\Http\Controllers\AssessmentController::class, 'assessmentDetail'])->name('assessments-details');


Route::get('/authorizations-listing', [App\Http\Controllers\AuthorizationController::class, 'index'])->name('authorizations-listing');
Route::get('/authorizations-add', [App\Http\Controllers\AuthorizationController::class, 'addAuthorization'])->name('authorizations-add');
Route::get('/authorizations-details', [App\Http\Controllers\AuthorizationController::class, 'authorizationDetail'])->name('authorizations-details');



Route::get('/serviceplan-listing', [App\Http\Controllers\ServicePlanController::class, 'index'])->name('serviceplan-listing');
Route::get('/serviceplan-add', [App\Http\Controllers\ServicePlanController::class, 'addServicePlan'])->name('serviceplan-add');
Route::get('/serviceplan-details', [App\Http\Controllers\ServicePlanController::class, 'servicePlanDetail'])->name('serviceplan-details');


Route::get('/consumer-notes-listing', [App\Http\Controllers\ConsumerNotesController::class, 'index'])->name('consumer-notes-listing');
Route::get('/consumer-notes-add', [App\Http\Controllers\ConsumerNotesController::class, 'addConsumerNote'])->name('consumer-notes-add');
Route::get('/consumer-notes-details', [App\Http\Controllers\ConsumerNotesController::class, 'consumerNoteDetail'])->name('consumer-notes-details');


Route::get('/employee-listing', [App\Http\Controllers\EmployeeController::class, 'index'])->name('employee-listing');
Route::any('/employee-add', [App\Http\Controllers\EmployeeController::class, 'addEmployee'])->name('employee-add');
Route::get('/employee-details/{id}', [App\Http\Controllers\EmployeeController::class, 'employeeDetail'])->name('employee-details');


Route::get('/roles', [App\Http\Controllers\RoleController::class, 'index'])->name('roles');
Route::any('/role-add', [App\Http\Controllers\RoleController::class, 'addRole'])->name('role-add');
Route::get('/role-details/{id}', [App\Http\Controllers\RoleController::class, 'roleDetail'])->name('role-details');
Route::any('/role-edit/{id}', [App\Http\Controllers\RoleController::class, 'editRole'])->name('role-edit');


Route::get('/certificate-types', [App\Http\Controllers\CertificateTypeController::class, 'index'])->name('certificate-types');
Route::any('/certificate-type-add', [App\Http\Controllers\CertificateTypeController::class, 'addType'])->name('certificate-type-add');
Route::get('/certificate-type-details/{id}', [App\Http\Controllers\CertificateTypeController::class, 'typeDetail'])->name('certificate-type-details');
Route::any('/certificate-type-edit/{id}', [App\Http\Controllers\CertificateTypeController::class, 'editType'])->name('certificate-type-edit');


Route::get('/notation-types', [App\Http\Controllers\NotationTypeController::class, 'index'])->name('notation-types');
Route::any('/notation-type-add', [App\Http\Controllers\NotationTypeController::class, 'addType'])->name('notation-type-add');
Route::get('/notation-type-details/{id}', [App\Http\Controllers\NotationTypeController::class, 'typeDetail'])->name('notation-type-details');
Route::any('/notation-type-edit/{id}', [App\Http\Controllers\NotationTypeController::class, 'editType'])->name('notation-type-edit');


Route::get('/routes', [App\Http\Controllers\RouteController::class, 'index'])->name('routes');
Route::any('/route-add', [App\Http\Controllers\RouteController::class, 'addRoute'])->name('route-add');
Route::get('/route-details/{id}', [App\Http\Controllers\RouteController::class, 'routeDetail'])->name('route-details');
Route::any('/route-edit/{id}', [App\Http\Controllers\RouteController::class, 'editRoute'])->name('route-edit');


Route::get('/reactions', [App\Http\Controllers\ReactionController::class, 'index'])->name('reactions');
Route::any('/reaction-add', [App\Http\Controllers\ReactionController::class, 'addReaction'])->name('reaction-add');
Route::get('/reaction-details/{id}', [App\Http\Controllers\ReactionController::class, 'reactionDetail'])->name('reaction-details');
Route::any('/reaction-edit/{id}', [App\Http\Controllers\ReactionController::class, 'editReaction'])->name('reaction-edit');



Route::get('/races', [App\Http\Controllers\RaceController::class, 'index'])->name('races');
Route::any('/race-add', [App\Http\Controllers\RaceController::class, 'addRace'])->name('race-add');
Route::get('/race-details/{id}', [App\Http\Controllers\RaceController::class, 'raceDetail'])->name('race-details');
Route::any('/race-edit/{id}', [App\Http\Controllers\RaceController::class, 'editRace'])->name('race-edit');



Route::get('/ethnicities', [App\Http\Controllers\EthnicityController::class, 'index'])->name('ethnicities');
Route::any('/ethnicity-add', [App\Http\Controllers\EthnicityController::class, 'addEthnicity'])->name('ethnicity-add');
Route::get('/ethnicity-details/{id}', [App\Http\Controllers\EthnicityController::class, 'ethnicityDetail'])->name('ethnicity-details');
Route::any('/ethnicity-edit/{id}', [App\Http\Controllers\EthnicityController::class, 'editEthnicity'])->name('ethnicity-edit');



Route::get('/languages', [App\Http\Controllers\LanguageController::class, 'index'])->name('languages');
Route::any('/language-add', [App\Http\Controllers\LanguageController::class, 'addLanguage'])->name('language-add');
Route::get('/language-details/{id}', [App\Http\Controllers\LanguageController::class, 'languageDetail'])->name('language-details');
Route::any('/language-edit/{id}', [App\Http\Controllers\LanguageController::class, 'editLanguage'])->name('language-edit');






