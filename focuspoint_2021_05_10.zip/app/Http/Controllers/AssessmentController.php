<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class AssessmentController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('auth');
    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Contracts\Support\Renderable
     */
    public function index()
    {
        return view('assessment/assessments-listing');
    }
    public function addAssessment()
    {
        return view('assessment/assessments-add');
    }
    public function assessmentDetail()
    {
        return view('assessment/assessments-details');
    }
}
