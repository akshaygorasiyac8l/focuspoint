<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use Illuminate\Foundation\Bus\DispatchesJobs;
use Illuminate\Contracts\Validation\Validator;
use Illuminate\Routing\Controller as BaseController;
use Illuminate\Foundation\Validation\ValidatesRequests;

use Illuminate\Support\Facades\Auth;
use DB;

class RoleController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('auth');
    }

    use DispatchesJobs, ValidatesRequests;

    /**
     * {@inheritdoc}
     */
    protected function formatValidationErrors(Validator $validator)
    {
        return $validator->errors()->all();
    }
    
    
    public function index()
    {
        $data = array();        
        $data['roles'] = DB::table('roles')->get();        
        return view('role/role-listing',$data);
    }
    public function addRole(Request $request)
    {
        if($request->isMethod('post')){
            
            
            
            //dd($request);
            $role = $request->input('role');
            $status = $request->input('status');
            
            DB::table('roles')
            ->insert([
                'role' => $role,
                'status' => $status,
            ]);
            
            return redirect('/roles');

        }else{
            return view('role/role-add');
        }
        
    }
    
    public function editRole(Request $request,$id)
    {
        if($request->isMethod('post')){
            
            
            

            $role = $request->input('role');
            $status = $request->input('status');
            
            DB::table('roles')
            ->where('id', $id)
            ->update([
                'role' => $role,
                'status' => $status,
            ]);
            
            return redirect('/roles');

        }else{
            $data = array();
            $data['role'] = DB::table('roles')->where('id', $id)->first();
            return view('role/role-edit',$data);
        }
        
    }
    
    
    public function roleDetail(Request $request,$id)
    {
        return view('role/role-details');
    }
    
    
    
}
