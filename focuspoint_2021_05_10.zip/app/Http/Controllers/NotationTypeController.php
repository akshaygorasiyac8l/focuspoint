<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use Illuminate\Foundation\Bus\DispatchesJobs;
use Illuminate\Contracts\Validation\Validator;
use Illuminate\Routing\Controller as BaseController;
use Illuminate\Foundation\Validation\ValidatesRequests;

use Illuminate\Support\Facades\Auth;
use DB;

class NotationTypeController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('auth');
    }

    use DispatchesJobs, ValidatesRequests;

    /**
     * {@inheritdoc}
     */
    protected function formatValidationErrors(Validator $validator)
    {
        return $validator->errors()->all();
    }
    
    
    public function index()
    {
        $data = array();        
        $data['notation_types'] = DB::table('notation_types')->get();        
        return view('notation/notation-type-listing',$data);
    }
    public function addType(Request $request)
    {
        if($request->isMethod('post')){
            
            
            
            //dd($request);
            $title = $request->input('title');
            
            
            DB::table('notation_types')
            ->insert([
                'title' => $title,
                
            ]);
            
            return redirect('/notation-types');

        }else{
            return view('notation/notation-type-add');
        }
        
    }
    
    public function editType(Request $request,$id)
    {
        if($request->isMethod('post')){
            
            
            

            $title = $request->input('title');
            
            DB::table('notation_types')
            ->where('id', $id)
            ->update([
                'title' => $title,
                
            ]);
            
            return redirect('/notation-types');

        }else{
            $data = array();
            $data['notation_type'] = DB::table('notation_types')->where('id', $id)->first();
            return view('notation/notation-type-edit',$data);
        }
        
    }
    
    
    public function typeDetail(Request $request,$id)
    {
        return view('notation/notation-type-details');
    }
    
    
    
}
