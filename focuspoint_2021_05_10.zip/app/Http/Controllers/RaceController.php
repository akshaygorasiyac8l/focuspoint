<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use Illuminate\Foundation\Bus\DispatchesJobs;
use Illuminate\Contracts\Validation\Validator;
use Illuminate\Routing\Controller as BaseController;
use Illuminate\Foundation\Validation\ValidatesRequests;

use Illuminate\Support\Facades\Auth;
use DB;

class RaceController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('auth');
    }

    use DispatchesJobs, ValidatesRequests;

    /**
     * {@inheritdoc}
     */
    protected function formatValidationErrors(Validator $validator)
    {
        return $validator->errors()->all();
    }
    
    
    public function index()
    {
        $data = array();        
        $data['races'] = DB::table('races')->get();        
        return view('race/race-listing',$data);
    }
    public function addRace(Request $request)
    {
        if($request->isMethod('post')){
            
            
            
            //dd($request);
            $title = $request->input('title');
            
            
            DB::table('races')
            ->insert([
                'title' => $title,
                
            ]);
            
            return redirect('/races');

        }else{
            return view('race/race-add');
        }
        
    }
    
    public function editRace(Request $request,$id)
    {
        if($request->isMethod('post')){
            
            
            

            $title = $request->input('title');
            
            DB::table('races')
            ->where('id', $id)
            ->update([
                'title' => $title,
                
            ]);
            
            return redirect('/races');

        }else{
            $data = array();
            $data['race'] = DB::table('races')->where('id', $id)->first();
            return view('race/race-edit',$data);
        }
        
    }
    
    
    public function raceDetail(Request $request,$id)
    {
        return view('race/race-details');
    }
    
    
    
}
