@extends('layouts.app')
@section('title', 'Home')
@section('script1')
@endsection

@section('content')
<div class="section">
       
       


    </div>
@endsection


@section('script2')
@endsection