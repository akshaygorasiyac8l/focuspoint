<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use DB;
use Hash;
class EmployeeController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('auth');
    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Contracts\Support\Renderable
     */
    public function index()
    {
        $data = array();        
        $data['employees'] = DB::table('users')->where('role_id','!=',0)->get();
        return view('employee/employee-listing',$data);
    }
    public function addEmployee(Request $request)
    {
        if($request->isMethod('post')){
            
            
            
            //dd($request);
            $salution = $request->input('salution');
            $fname = $request->input('fname');
            $lname = $request->input('lname');
            $email = $request->input('email');
            $country = $request->input('country');
            $time = $request->input('time');
            $gender = $request->input('gender');
            $bod = $request->input('bod');
            $role_id = $request->input('role_id');
            $password = $request->input('password');
            $final_password = Hash::make($password);
            //$role_id = $request->input('role_id');
            
            $id = DB::table('users')
            ->insertGetId([
                'salution' => $salution,'fname' => $fname,'lname' => $lname,
                'email' => $email,'country' => $country,
                'time' => $time,
                'gender' => $gender,
                'bod' => $bod,
                'role_id' => $role_id,
                'password' => $final_password,
                'status' => 1,
            ]);
            
            
            if($request->hasfile('filenames'))
            {
                
                foreach($request->file('filenames') as $file)
                {
                    
                    
                    $name = time().uniqid().'.'.$file->extension();
                    $file->move(public_path().'/files/', $name);  
                    DB::table('user_documents')
                    ->insert([
                        'user_id' => $id,
                        'document' => $name,
                    ]);
                      
                }
            }


            
            
            return redirect('/employee-listing');

        }else{
            $data = array();
            $data['roles'] = DB::table('roles')->get();
            return view('employee/employee-add',$data);
        }
        
    }
    public function employeeDetail(Request $request,$id)
    {
        $data = array();
        $data['employee'] = DB::table('users')->where('id',$id)->first();
        return view('employee/employee-details',$data);
    }
}
