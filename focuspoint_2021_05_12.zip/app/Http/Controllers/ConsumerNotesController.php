<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use DB;

class ConsumerNotesController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('auth');
    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Contracts\Support\Renderable
     */
    public function index()
    {
        return view('consumernote/consumer-notes-listing');
    }
    public function addConsumerNote()
    {
        return view('consumernote/consumer-notes-add');
    }
    public function consumerNoteDetail()
    {
        return view('consumernote/consumer-notes-details');
    }


    public function consumerNoteType()
    {
        $data = array();        
        $data['consumer_note_types'] = DB::table('consumer_note_types')->get();        
        return view('consumer_note_type/consumer-note-type-listing',$data);
    }
    public function addconsumerNoteType(Request $request)
    {
        if($request->isMethod('post')){
            
            
            
            //dd($request);
            $title = $request->input('title');
            $status = $request->input('status');
            
            DB::table('consumer_note_types')
            ->insert([
                'title' => $title
            ]);
            
            return redirect('/consumer-note-types');
           

        }else{
            return view('consumer_note_type/consumer-note-type-add');
        }
        
    }
    
    public function editConsumerNoteType(Request $request,$id)
    {
        if($request->isMethod('post')){
            
            
            

            $title = $request->input('title');
            
            
            DB::table('consumer_note_types')
            ->where('id', $id)
            ->update([
                'title' => $title
            ]);
            
            return redirect('/consumer-note-types');

        }else{
            $data = array();
            $data['consumer_note_type'] = DB::table('consumer_note_types')->where('id', $id)->first();
            return view('consumer_note_type/consumer-note-type-edit',$data);
        }
        
    }
    
    
    public function consumerNoteTypeDetail(Request $request,$id)
    {
        return view('consumer_note_type/consumer-note-type-details');
    }
    

    
}
