<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use Illuminate\Foundation\Bus\DispatchesJobs;
use Illuminate\Contracts\Validation\Validator;
use Illuminate\Routing\Controller as BaseController;
use Illuminate\Foundation\Validation\ValidatesRequests;

use Illuminate\Support\Facades\Auth;
use DB;

class LanguageController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('auth');
    }

    use DispatchesJobs, ValidatesRequests;

    /**
     * {@inheritdoc}
     */
    protected function formatValidationErrors(Validator $validator)
    {
        return $validator->errors()->all();
    }
    
    
    public function index()
    {
        $data = array();        
        $data['languages'] = DB::table('languages')->get();        
        return view('language/language-listing',$data);
    }
    public function addLanguage(Request $request)
    {
        if($request->isMethod('post')){
            
            
            
            //dd($request);
            $title = $request->input('title');
            
            
            DB::table('languages')
            ->insert([
                'title' => $title,
                
            ]);
            
            return redirect('/languages');

        }else{
            return view('language/language-add');
        }
        
    }
    
    public function editLanguage(Request $request,$id)
    {
        if($request->isMethod('post')){
            
            
            

            $title = $request->input('title');
            
            DB::table('languages')
            ->where('id', $id)
            ->update([
                'title' => $title,
                
            ]);
            
            return redirect('/languages');

        }else{
            $data = array();
            $data['language'] = DB::table('languages')->where('id', $id)->first();
            return view('language/language-edit',$data);
        }
        
    }
    
    
    public function languageDetail(Request $request,$id)
    {
        return view('language/language-details');
    }
    
    
    
}
