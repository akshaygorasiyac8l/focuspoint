<!doctype html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- CSRF Token -->
    

    <title><?php echo e(config('app.name', 'Focus Point')); ?></title>
    
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/bootstrap.min.css')); ?>">
	<link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/custom.css')); ?>">
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
	<script type="text/javascript" src="<?php echo e(asset('js/jquery.min.js')); ?>"></script>
	<script type="text/javascript" src="<?php echo e(asset('js/jquery.validate.min.js')); ?>"></script>
    
	<link rel="stylesheet" type="text/css" href="<?php echo e(asset('font/font.css')); ?>">
    <style>
    .dataTables_length select{background-image:none !important;}
    .consumer-section{padding:15px;}
    .action-icon{font-size:20px;}
    </style>
    
    
    <?php $__env->startSection('script1'); ?>
      <link rel="stylesheet" href="<?php echo e(asset('css/jquery-ui.css')); ?>">

      <link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/jquery-ui-timepicker-addon.css')); ?>">
      <link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/jquery.dataTables.min.css')); ?>">
      <link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/select.dataTables.min.css')); ?>">
      <link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/bootstrap-datetimepicker.css')); ?>">
      <!-- <script type="text/javascript" src="js/jquery.min.js"></script> -->
      <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/jquery/2.2.0/jquery.min.js"></script>
      <script src="http://code.jquery.com/ui/1.11.0/jquery-ui.js"></script>
      <script type="text/javascript" src="<?php echo e(asset('js/jquery.validate.min.js')); ?>"></script>
      <script type="text/javascript" src="<?php echo e(asset('js/app.js')); ?>"></script>
      <script type="text/javascript" src="<?php echo e(asset('js/bootstrap.min.js')); ?>"></script>
      <script type="text/javascript" src="<?php echo e(asset('js/jquery.dataTables.min.js')); ?>"></script>
    <?php echo $__env->yieldSection(); ?> 
    <?php $__env->startSection('add_layout'); ?>
         <link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/jquery-ui-timepicker-addon.css')); ?>">
         <link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/jquery.dataTables.min.css')); ?>">
         <link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/select.dataTables.min.css')); ?>">
         <link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/bootstrap-datetimepicker.css')); ?>">
         <!-- <script type="text/javascript" src="js/jquery.min.js"></script> -->
         <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/jquery/2.2.0/jquery.min.js"></script>
         <script src="http://code.jquery.com/ui/1.11.0/jquery-ui.js"></script>
         <script type="text/javascript" src="<?php echo e(asset('js/jquery.validate.min.js')); ?>"></script>
         <script type="text/javascript" src="<?php echo e(asset('js/app.js')); ?>"></script>
         <script type="text/javascript" src="<?php echo e(asset('js/bootstrap.min.js')); ?>"></script>
         <script type="text/javascript" src="<?php echo e(asset('js/jquery.dataTables.min.js')); ?>"></script>
    <?php echo $__env->yieldSection(); ?>
    <?php $__env->startSection('listing_layout'); ?>
       <link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/jquery.dataTables.min.css')); ?>">
       <link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/select.dataTables.min.css')); ?>">
       <script type="text/javascript" src="<?php echo e(asset('js/jquery.min.js')); ?>"></script>
       <script type="text/javascript" src="<?php echo e(asset('js/jquery.dataTables.min.js')); ?>"></script>
       <script type="text/javascript" src="<?php echo e(asset('js/dataTables.select.min.js')); ?>"></script>
       <script type="text/javascript">
               $(document).ready(function() {
                   $('#table-general').DataTable( {

                   "fixedHeader":    true,
                   "bInfo" :         false,
                   "bSortable":      false,
                   searching:        false,
                   paging:           false,
                   fixedColumns: {
                       leftColumns: 1,
                       rightColumns: 1
                   },
                   columnDefs: [ {
                       orderable: false,
                       className: 'select-checkbox',
                       targets:   0
                   } ],
                   select: {
                       style:    'multi',
                       selector: 'td:first-child'
                   },
                   order: [[ 1, 'asc' ]]
                
                
               });
               //       var  DT1 = $('#table-general').DataTable();
               // $(".selectAll").on( "click", function(e) {
               //     if ($(this).is( ":checked" )) {
               //         DT1.rows(  ).select();        
               //     } else {
               //         DT1.rows(  ).deselect(); 
               //     }
               // });

               } );
         </script>
      <?php echo $__env->yieldSection(); ?>
    <?php $__env->startSection('detail_layout'); ?>
      <link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/jquery.dataTables.min.css')); ?>">
      <link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/select.dataTables.min.css')); ?>">
      <script type="text/javascript" src="<?php echo e(asset('js/jquery.min.js')); ?>"></script>
      <script src="<?php echo e(asset('js/jquery-ui.js')); ?>"></script>
      <script type="text/javascript" src="<?php echo e(asset('js/app.js')); ?>"></script>
      <script type="text/javascript" src="<?php echo e(asset('js/jquery.dataTables.min.js')); ?>"></script>
      <script type="text/javascript" src="<?php echo e(asset('js/dataTables.select.min.js')); ?>"></script>
      <script type="text/javascript" src="<?php echo e(asset('js/bootstrap.min.js')); ?>"></script>
   <?php echo $__env->yieldSection(); ?>
</head>
<body>
        
<?php $__env->startSection('header'); ?>  
         <div class="header">
            <div class="mobile-section">
               <div class="logo">
                  <a href="<?php echo e(route('home')); ?>">
                     <img src="<?php echo e(asset('images/FocusPoint_Logo.png')); ?>" alt="logo">
                  </a>
               </div>
               <div class="mobile-menu">
                  <button onclick="myFunction();"><i class="fa fa-bars" aria-hidden="true"></i></button>
               </div>
            </div>
            
            <div class="row header-right-section" id="header-section-mobile">
              <div class="col-md-6 search-box">
                  <form class="form-inline ml-3">
                     <div class="input-group input-group-sm">                     
                       <i class="fa fa-caret-down"></i>
                       <input class="form-control form-control-navbar" type="text" name="search" placeholder="Search" aria-label="Search">
                     </div>
                   </form>
               </div>
               <div class="col-md-6 drop-box">
                  <ul class="droup-down-box">
                     <li class="drop-item-box">
                        <div class="form-group select dropdown-box">                           
                           <select class="form-control droupdown" name="locations" style="-webkit-appearance: none;">
                              <option selected="selected" disabled="disabled" value="Locations">Locations</option>
                              <option value="Danville">Danville</option>  
                              <option value="Martinsville">Martinsville</option>
                              <option value="Richmond">Richmond</option>
                           </select>
                           <i class="fa fa-angle-down"></i>
                        </div>
                     </li>
                     <?php
                     if (Auth::check()) {
                        $user = \Auth::user(); 
                        $role_id = $user->role_id;
                     }
                     if(isset($role_id) && $role_id=='0'){
                     ?>
                     <li class="drop-item-box">
                        <div class="form-group select dropdown-box">
                           <select class="form-control droupdown" name="administration" style="-webkit-appearance: none;">
                              <optgroup class="dropdown-title" label="Access Management">
                                 <option selected="selected" value="Administration">Administration</option>
                                 <option value="Users">Users</option>
                                 <option value="Roles">Roles</option>
                                 <option value="Groups">Groups</option>
                              </optgroup>
                              <optgroup label="Server Settings">
                                 <option value="Global Settings">Global Settings</option>
                                 <option value="Database Export">Database Export</option>
                              </optgroup>
                           </select>
                           <i class="fa fa-angle-down"></i>
                        </div>
                     </li>
                     <?php } ?>
                     <li class="profile-drop">
                        <img src="<?php echo e(asset('images/user.png')); ?>" alt="User Avatar" class="img-circle user-icon" id="user-add-icon">
                        <ul id="drop-down-profile">
                           <li class="nav-item profile">
                              <a href="<?php echo e(route('profile')); ?>" class="dropdown-item">Profile</a>
                           </li>
                           <li class="nav-item profile">
                              <a  class="dropdown-item" href="<?php echo e(route('logout')); ?>"
                       onclick="event.preventDefault();
                                     document.getElementById('logout-form').submit();">Logout</a>
                           </li>
                        </ul>
                     </li>
                  </ul>
               </div>
            </div>
         </div>
 
 
<?php echo $__env->yieldSection(); ?>        

<?php $__env->startSection('sidebar'); ?>  
        <aside class="main-sidebar sidebar-dark-primary elevation-4" id="sidebar">
            <nav class="mt-2">
               <ul class="nav nav-pills nav-sidebar flex-column" data-widget="treeview" role="menu" data-accordion="false">
                  <li class="nav-item has-treeview active-menu">
                     <a href="<?php echo e(route('home')); ?>" class="nav-link">
                        <i class="fa fa-dashboard"></i>
                        <p>Dashboard</p>
                     </a>
                  </li>
                  <?php
                  if(isset($role_id) && $role_id=='0'){
                  ?>
                  <li class="nav-item has-treeview ">
                     <a href="<?php echo e(route('roles')); ?>" class="nav-link">
                        <i class="fa fa-dashboard"></i>
                        <p>Roles</p>
                     </a>
                  </li>
                  <li class="nav-item has-treeview ">
                     <a href="<?php echo e(route('certificate-types')); ?>" class="nav-link">
                        <i class="fa fa-dashboard"></i>
                        <p>Certification Types</p>
                     </a>
                  </li>
                  <li class="nav-item has-treeview ">
                     <a href="<?php echo e(route('notation-types')); ?>" class="nav-link">
                        <i class="fa fa-dashboard"></i>
                        <p>Notation Types</p>
                     </a>
                  </li>
                  <li class="nav-item has-treeview ">
                     <a href="<?php echo e(route('route-listing')); ?>" class="nav-link">
                        <i class="fa fa-dashboard"></i>
                        <p>Routes</p>
                     </a>
                  </li>
                  
                  <li class="nav-item has-treeview ">
                     <a href="<?php echo e(route('reactions')); ?>" class="nav-link">
                        <i class="fa fa-dashboard"></i>
                        <p>Reactions</p>
                     </a>
                  </li>
                  
                  <li class="nav-item has-treeview ">
                     <a href="<?php echo e(route('races')); ?>" class="nav-link">
                        <i class="fa fa-dashboard"></i>
                        <p>Races</p>
                     </a>
                  </li>
                  
                  <li class="nav-item has-treeview ">
                     <a href="<?php echo e(route('ethnicities')); ?>" class="nav-link">
                        <i class="fa fa-dashboard"></i>
                        <p>Ethnicities</p>
                     </a>
                  </li>
                  
                  <li class="nav-item has-treeview ">
                     <a href="<?php echo e(route('languages')); ?>" class="nav-link">
                        <i class="fa fa-dashboard"></i>
                        <p>Languages</p>
                     </a>
                  </li>
                  
                  <li class="nav-item has-treeview ">
                     <a href="<?php echo e(route('locations')); ?>" class="nav-link">
                        <i class="fa fa-dashboard"></i>
                        <p>Locations</p>
                     </a>
                  </li>
                  
                  <li class="nav-item has-treeview ">
                     <a href="<?php echo e(route('relations')); ?>" class="nav-link">
                        <i class="fa fa-dashboard"></i>
                        <p>Relations</p>
                     </a>
                  </li>
                  <li class="nav-item has-treeview ">
                     <a href="<?php echo e(route('problems')); ?>" class="nav-link">
                        <i class="fa fa-dashboard"></i>
                        <p>Problems</p>
                     </a>
                  </li>
                  <li class="nav-item has-treeview ">
                     <a href="<?php echo e(route('payers')); ?>" class="nav-link">
                        <i class="fa fa-dashboard"></i>
                        <p>Payers</p>
                     </a>
                  </li>
                  <li class="nav-item has-treeview ">
                     <a href="<?php echo e(route('services')); ?>" class="nav-link">
                        <i class="fa fa-dashboard"></i>
                        <p>Services</p>
                     </a>
                  </li>
                  
                  <li class="nav-item has-treeview ">
                     <a href="<?php echo e(route('pay-types')); ?>" class="nav-link">
                        <i class="fa fa-dashboard"></i>
                        <p>Pay Types</p>
                     </a>
                  </li>
                  
                  <li class="nav-item has-treeview ">
                     <a href="<?php echo e(route('assessment-types')); ?>" class="nav-link">
                        <i class="fa fa-dashboard"></i>
                        <p>Assessment Types</p>
                     </a>
                  </li>

                  
                  <?php } ?>
                  <li class="nav-item has-treeview">
                     <a href="<?php echo e(route('consumers-listing')); ?>" class="nav-link">
                        <i class="fa fa-user"></i>
                        <p>Consumers</p>
                     </a>
                  </li>
                  <li class="nav-item has-treeview">
                     <a href="<?php echo e(route('assessments-listing')); ?>" class="nav-link">
                        <i class="fa fa-anchor"></i>
                        <p>Assessments</p>
                     </a>
                  </li>                  
                  <li class="nav-item has-treeview">
                     <a href="<?php echo e(route('authorizations-listing')); ?>" class="nav-link">
                        <i class="fa fa-check-square-o"></i>
                        <p>Authorizations</p>
                     </a>
                  </li>
                  <li class="nav-item has-treeview">
                     <a href="<?php echo e(route('serviceplan-listing')); ?>" class="nav-link">
                        <i class="fa fa-life-ring"></i>
                        <p>Service Plans</p>
                     </a>
                  </li>
                  <li class="nav-item has-treeview">
                     <a href="<?php echo e(route('consumer-notes-listing')); ?>" class="nav-link">
                        <i class="fa fa-book"></i>
                        <p>Consumer Notes</p>
                     </a>
                  </li>
                  <!--
                  <li class="nav-item has-treeview">
                     <a href="#" class="nav-link">
                        <i class="fa fa-database"></i>
                        <p>Compliances</p>
                     </a>
                  </li>
                  -->
                  <li class="nav-item has-treeview">
                     <a href="<?php echo e(route('employee-listing')); ?>" class="nav-link">
                        <i class="fa fa-user"></i>
                        <p>Employees</p>
                     </a>
                  </li>
                  <!--
                  <li class="nav-item has-treeview">
                     <a href="#" class="nav-link">
                        <i class="fa fa-file"></i>
                        <p>Reports</p>
                     </a>
                  </li>
                  
                  <li class="nav-item has-treeview">
                     <a href="#" class="nav-link">
                        <i class="fa fa-credit-card"></i>
                        <p>Billing</p>
                     </a>
                     
                     
                  </li>
                  -->
                  <li class="nav-item has-treeview">
                  <a class="nav-link" href="<?php echo e(route('logout')); ?>"
                       onclick="event.preventDefault();
                                     document.getElementById('logout-form').submit();">
                                     <i class="fa fa-life-ring"></i>
                        <p><?php echo e(__('Logout')); ?></p>
                    </a>

                    <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" class="d-none">
                        <?php echo csrf_field(); ?>
                    </form>
                   </li>
               </ul>
               <!--
               <div class="row header-right-section" id="desktop-hide">
                  <div class="col-md-6 search-box">
                     <form class="form-inline ml-3">
                        <div class="input-group input-group-sm">                     
                          <i class="fa fa-caret-down"></i>
                          <input class="form-control form-control-navbar" type="text" name="search" placeholder="Search" aria-label="Search">
                        </div>
                      </form>
                  </div>
                  <div class="col-md-6 drop-box">
                     <ul class="droup-down-box">
                        <li class="drop-item-box">
                           <div class="form-group select dropdown-box">                           
                              <select class="form-control droupdown" name="locations" style="-webkit-appearance: none;">
                                 <option selected="selected" value="Locations">Locations</option>
                                 <option value="Danville">Danville</option>  
                                 <option value="Martinsville">Martinsville</option>
                                 <option value="Richmond">Richmond</option>
                              </select>
                              <i class="fa fa-angle-down"></i>
                           </div>
                        </li>
                        <li class="drop-item-box">
                           <div class="form-group select dropdown-box">
                              <select class="form-control droupdown" name="administration" style="-webkit-appearance: none;">
                                 <optgroup class="dropdown-title" label="Access Management">
                                    <option selected="selected" value="Administration">Administration</option>
                                    <option value="Users">Users</option>
                                    <option value="Roles">Roles</option>
                                    <option value="Groups">Groups</option>
                                 </optgroup>
                                 <optgroup label="Server Settings">
                                    <option value="Global Settings">Global Settings</option>
                                    <option value="Database Export">Database Export</option>
                                 </optgroup>
                              </select>
                              <i class="fa fa-angle-down"></i>
                           </div>
                        </li>
                        <li class="profile-drop">
                           <img src="images/user.png" alt="User Avatar" class="img-circle user-icon" id="user-add-icon">
                           <ul id="drop-down-profile">
                              <li class="nav-item profile">
                                 <a href="profile.html" class="dropdown-item">Profile</a>
                              </li>
                              <li class="nav-item profile">
                                 <a href="#" class="dropdown-item">Logout</a>
                              </li>
                           </ul>
                        </li>
                     </ul>
                  </div>
               </div>
               <ul id="desktop-user">
                  <li id="user-mobile-add">
                     <img src="images/user.png" alt="User Avatar" class="img-circle user-icon" id="user-mobile-icon">
                  </li>
               </ul>
               <ul id="mobile-dropdown">
                  <li class="nav-item profile">
                     <a href="profile.html" class="dropdown-item">Profile</a>
                  </li>
                  <li class="nav-item profile">
                     <a href="#" class="dropdown-item">Logout</a>
                     
                  </li>
               </ul>  
               -->
            </nav>
            <div class="back-box">
               <button class="back-btn-box"><i class="fa fa-angle-left"></i></button>
            </div>
         </aside>
         
      
         <input type="hidden" id="csrf_token" name="csrf"  value="<?php echo e(csrf_token()); ?>" />
  
<?php echo $__env->yieldSection(); ?>   


<?php echo $__env->yieldContent('content'); ?>
        
<?php echo $__env->yieldContent('script'); ?>
<script type="text/javascript">

   $('.nav-tabs').on('click', 'li', function() {
     $('.nav-tabs li.active-tabs').removeClass('active-tabs');
     $(this).addClass('active-tabs');
   });

   $('.nav-sidebar').on('click', 'li', function() {
     $('.nav-sidebar li.active-menu').removeClass('active-menu');
     $(this).addClass('active-menu');
   });

   // Dropdown open and close
   $('#user-add-icon').click(function(){
      $("#drop-down-profile").toggleClass('show');
   });

    $('#user-mobile-icon').click(function(){
      $("#mobile-dropdown").toggleClass('show-add');
   });
  
</script>

<?php $__env->startSection('script2'); ?>
<script src="https://trentrichardson.com/examples/timepicker/jquery-ui-timepicker-addon.js"></script>
<script type="text/javascript" src="<?php echo e(asset('js/moment.min.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('js/angular.min.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('js/bootstrap-datetimepicker.min.js')); ?>"></script>
<script type="text/javascript">
   $('.nav-sidebar').on('click', 'li', function() {
     $('.nav-sidebar li.active-menu').removeClass('active-menu');
     $(this).addClass('active-menu');
   });
</script>
<script type="text/javascript">
   $(document).ready(function() {
       $('.date-select').datepicker({ format: "mm/dd/yyyy" });
   }); 
   $(document).ready(function() {
       $('.diagnosis-date').datepicker({ format: "mm/dd/yyyy" });
   }); 
   $(document).ready(function() {
       $('.date-type').datepicker({ format: "mm/dd/yyyy" });
   }); 


   // Scroolbar scroll
   var $hs = $('.table-scrollbar');
   var $sLeft = 0;
   var $hsw = $hs.outerWidth(true);
   $( window ).resize(function() {
     $hsw = $hs.outerWidth(true);
   });
   function scrollMap($sLeft) {
     $hs.scrollLeft($sLeft);
   }
   $hs.on('mousewheel', function(e) {
     var $max = $hsw * 2 + (-e.originalEvent.wheelDeltaY);
     if ($sLeft > -1){
       $sLeft = $sLeft + (-e.originalEvent.wheelDeltaY);
     } else {
       $sLeft = 0;
     }
     if ($sLeft > $max) {
       $sLeft = $max;
     }
     if(($sLeft > 0) && ($sLeft < $max)) {
       e.preventDefault();
       e.stopPropagation(); 
     }
     scrollMap($sLeft);
   });

   $('#user-add-icon').click(function(){
      $("#drop-down-profile").toggleClass('show');
   });

    $('#user-mobile-icon').click(function(){
      $("#mobile-dropdown").toggleClass('show-add');
   });
   
   $("#spent-time-add").timepicker();


// Spent Time Add
$(document).ready(function() {
   $('.start-date').datepicker({ format: "mm/dd/yyyy" });
});
$(document).ready(function() {
   $('.end-date').datepicker({ format: "mm/dd/yyyy" });
});
$("#start-time").timepicker();
$("#end-time").timepicker(); 
</script>

<script type="text/javascript">
$(function() {
  $("form[name='assessment-form']").validate({
    rules: {
      consumername: "required",
      payername: "required",
      assessmenttype: "required"
    },
    messages: {
      consumername: "Please enter your Consumer Name",
      payername: "Please enter your Payer Name",
      assessmenttype: "Please enter your Type"
    },
    submitHandler: function(form) {
      form.submit();
    }
  });
});

// Images Preview JS
function readImage(file) {
  var reader = new FileReader();
  var image  = new Image();

  reader.readAsDataURL(file);  
  reader.onload = function(_file) {
    image.src = _file.target.result;
    image.onload = function() {
      var n = file.name;
      $('#uploadPreview').append('<div class="image-section"><div class="row"><div class="col-md-8"><p class="file-name-image">' + n + '</p></div><div class="col-md-4"><span class="delete-image"><i class="fa fa-trash delete" aria-hidden="true"></i>Delete</span></div></div></div>');
      $('.delete-image').click(function(){
        $(this).parent().parent().parent().remove();
      });
    };

    image.onerror= function() {
      alert('Invalid file type: '+ file.type);
    };    
  };
}
$("#file-upload").change(function (e) {
  if(this.disabled) {
    return alert('File upload not supported!');
  }
  var F = this.files;
  if (F && F[0]) {
    for (var i = 0; i < F.length; i++) {
      readImage(F[i]);
    }
  }
});

$('.common-selectbox').click(function(){
   $('.common-selectbox').toggleClass('add-down-arrow-show');
});

// Date and Time Picker
$(function () {
   $('#startdatetimepicker').datetimepicker({ 
      allowInputToggle: true,
      format: 'YYYY-MMM-DD HH:mm',
      inline: false,
      sideBySide: true
   }); 
});
$(function () {
   $('#enddatetimepicker').datetimepicker({ 
      allowInputToggle: true,
      format: 'YYYY-MMM-DD HH:mm',
      inline: false,
      sideBySide: true
   }); 
});
</script>
<?php echo $__env->yieldSection(); ?> 

<?php $__env->startSection('end_add_layout'); ?>
<script src="https://trentrichardson.com/examples/timepicker/jquery-ui-timepicker-addon.js"></script>

<script type="text/javascript" src="<?php echo e(asset('js/moment.min.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('js/angular.min.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('js/bootstrap-datetimepicker.min.js')); ?>"></script>
<script type="text/javascript">
   $('.nav-sidebar').on('click', 'li', function() {
     $('.nav-sidebar li.active-menu').removeClass('active-menu');
     $(this).addClass('active-menu');
   });
</script>
<script type="text/javascript">
   $(document).ready(function() {
       $('.date-select').datepicker({ format: "mm/dd/yyyy" });
   }); 
   $(document).ready(function() {
       $('.diagnosis-date').datepicker({ format: "mm/dd/yyyy" });
   }); 
   $(document).ready(function() {
       $('.date-type').datepicker({ format: "mm/dd/yyyy" });
   }); 


   // Scroolbar scroll
   var $hs = $('.table-scrollbar');
   var $sLeft = 0;
   var $hsw = $hs.outerWidth(true);
   $( window ).resize(function() {
     $hsw = $hs.outerWidth(true);
   });
   function scrollMap($sLeft) {
     $hs.scrollLeft($sLeft);
   }
   $hs.on('mousewheel', function(e) {
     var $max = $hsw * 2 + (-e.originalEvent.wheelDeltaY);
     if ($sLeft > -1){
       $sLeft = $sLeft + (-e.originalEvent.wheelDeltaY);
     } else {
       $sLeft = 0;
     }
     if ($sLeft > $max) {
       $sLeft = $max;
     }
     if(($sLeft > 0) && ($sLeft < $max)) {
       e.preventDefault();
       e.stopPropagation(); 
     }
     scrollMap($sLeft);
   });

   $('#user-add-icon').click(function(){
      $("#drop-down-profile").toggleClass('show');
   });

    $('#user-mobile-icon').click(function(){
      $("#mobile-dropdown").toggleClass('show-add');
   });
   
   $("#spent-time-add").timepicker();


// Spent Time Add
$(document).ready(function() {
   $('.start-date').datepicker({ format: "mm/dd/yyyy" });
});
$(document).ready(function() {
   $('.end-date').datepicker({ format: "mm/dd/yyyy" });
});
$("#start-time").timepicker();
$("#end-time").timepicker(); 
</script>

<script type="text/javascript">
$(function() {
  $("form[name='assessment-form']").validate({
    rules: {
      consumername: "required",
      payername: "required",
      assessmenttype: "required"
    },
    messages: {
      consumername: "Please enter your Consumer Name",
      payername: "Please enter your Payer Name",
      assessmenttype: "Please enter your Type"
    },
    submitHandler: function(form) {
      form.submit();
    }
  });
});

// Images Preview JS
function readImage(file) {
  var reader = new FileReader();
  var image  = new Image();

  reader.readAsDataURL(file);  
  reader.onload = function(_file) {
    image.src = _file.target.result;
    image.onload = function() {
      var n = file.name;
      $('#uploadPreview').append('<div class="image-section"><div class="row"><div class="col-md-8"><p class="file-name-image">' + n + '</p></div><div class="col-md-4"><span class="delete-image"><i class="fa fa-trash delete" aria-hidden="true"></i>Delete</span></div></div></div>');
      $('.delete-image').click(function(){
        $(this).parent().parent().parent().remove();
      });
    };

    image.onerror= function() {
      alert('Invalid file type: '+ file.type);
    };    
  };
}
$("#file-upload").change(function (e) {
  if(this.disabled) {
    return alert('File upload not supported!');
  }
  var F = this.files;
  if (F && F[0]) {
    for (var i = 0; i < F.length; i++) {
      readImage(F[i]);
    }
  }
});

$('.common-selectbox').click(function(){
   $('.common-selectbox').toggleClass('add-down-arrow-show');
});

// Date and Time Picker
$(function () {
   $('#startdatetimepicker').datetimepicker({ 
      allowInputToggle: true,
      format: 'YYYY-MMM-DD HH:mm',
      inline: false,
      sideBySide: true
   }); 
});
$(function () {
   $('#enddatetimepicker').datetimepicker({ 
      allowInputToggle: true,
      format: 'YYYY-MMM-DD HH:mm',
      inline: false,
      sideBySide: true
   }); 
});
</script>
<?php echo $__env->yieldSection(); ?>
<?php $__env->startSection('end_listing_layout'); ?>
<script type="text/javascript">
   // Sidebar active menu js
   $('.nav-sidebar').on('click', 'li', function() {
    $('.nav-sidebar li.active-menu').removeClass('active-menu');
       $(this).addClass('active-menu');
   });

   // Mobile Menu active Js
   function myFunction() {
     var x = document.getElementById("sidebar");
     if (x.className === "main-sidebar") {
       x.className += " sidebar-hide";
     } else {
       x.className = "main-sidebar";
     }
   }

   $('#user-add-icon').click(function(){
      $("#drop-down-profile").toggleClass('show');
   });

    $('#user-mobile-icon').click(function(){
      $("#mobile-dropdown").toggleClass('show-add');
   });
    
</script>
<?php echo $__env->yieldSection(); ?>
<?php $__env->startSection('end_detail_layout'); ?>
<script src="https://trentrichardson.com/examples/timepicker/jquery-ui-timepicker-addon.js"></script>
<script type="text/javascript">
   $('.nav-tabs').on('click', 'li', function() {
     $('.nav-tabs li.active-tabs').removeClass('active-tabs');
     $(this).addClass('active-tabs');
   });

   $('.nav-sidebar').on('click', 'li', function() {
     $('.nav-sidebar li.active-menu').removeClass('active-menu');
     $(this).addClass('active-menu');
   });
</script>
<script type="text/javascript">
   $(document).ready(function() {
       $('.date-select').datepicker({ format: "mm/dd/yyyy" });
   }); 
   $(document).ready(function() {
       $('.diagnosis-date').datepicker({ format: "mm/dd/yyyy" });
   }); 
   $(document).ready(function() {
       $('.date-type').datepicker({ format: "mm/dd/yyyy" });
   }); 

   $("#spent-time-add").timepicker();

//Attach File Count Js
( function( $, window, document, undefined )
{
   $( '.file-new-upload' ).each( function()
   {
      var $input   = $( this ),
      $label    = $input.next( 'label' ),
      labelVal = $label.html();

      $input.on( 'change', function( e )
      {
         var fileName = '';

         if( this.files && this.files.length > 0 )
            fileName = ( this.getAttribute( 'data-multiple-caption' ) || '' ).replace( '{count}', this.files.length );
         else if( e.target.value )
            fileName = e.target.value.split( '\\' ).pop();

         if( fileName )
            $label.find( '.archive-name').html( fileName );
         else
            $label.html( labelVal );
      });
   });
})( jQuery, window, document );
</script>
<?php echo $__env->yieldSection(); ?>

</body>
</html>
<?php /**PATH C:\wamp\www\laravel\laravel8\focuspoint\resources\views/layouts/app.blade.php ENDPATH**/ ?>