<?php $__env->startSection('script1'); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
	<?php $__env->startSection('header'); ?>
		
	<?php $__env->stopSection(); ?>

	<?php $__env->startSection('sidebar'); ?>
		
	<?php $__env->stopSection(); ?> 

<div class="section-background	">
		<div class="container">
			<div class="row">
				<div class="col-md-12">
					<div class="login-box">
						<img src="images/FocusPoint_Logo.png" alt="Logo" class="img-responsive logo-set">
						<h4 class="login-title">Login</h4>
						<form method="POST" action="<?php echo e(route('login')); ?>">
                        <?php echo csrf_field(); ?>
							<div class="form-group">
								<input id="email" type="email"  name="email" class="form-control <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="Email Address" required autocomplete="email" autofocus>
                                <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
							</div>
							<div class="form-group">
								<input id="password" type="password" class="form-control <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="password" required autocomplete="current-password" placeholder="Password">
                                <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
							</div>
							<div class="sec-remember">
								<div class="form-group check-rem">
									<input type="checkbox" class="form-control check" placeholder="Username / Email Address">
									<label class="remember-me">Remember Me</label>
								</div>
								<div class="form-group forget">
									<a href="" class="forget-password">Forgot Password</a>
								</div>
							</div>
							<div class="form-group btn-sec">
								<button type="submit" class="btn btn-info login-btn">Login</button>
							</div>
						</form>
					</div>
				</div>
			</div>
		</div>
	</div>


<?php $__env->stopSection(); ?>
<?php $__env->startSection('script2'); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp\www\laravel\laravel8\focuspoint\resources\views/auth/login.blade.php ENDPATH**/ ?>