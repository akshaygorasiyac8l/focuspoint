<?php $__env->startSection('script1'); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('add_layout'); ?>   
<?php $__env->stopSection(); ?>
<?php $__env->startSection('listing_layout'); ?>
    ##parent-placeholder-34c9d66d4089e6254c65448001e01f951d92958c##

<?php $__env->stopSection(); ?>
<?php $__env->startSection('detail_layout'); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
	<?php $__env->startSection('header'); ?>
		##parent-placeholder-594fd1615a341c77829e83ed988f137e1ba96231##
	<?php $__env->stopSection(); ?>

	<?php $__env->startSection('sidebar'); ?>
		##parent-placeholder-19bd1503d9bad449304cc6b4e977b74bac6cc771##
	<?php $__env->stopSection(); ?> 
    
         <div class="content-wrapper">
            <div class="background-transperent">
               <section class="content-header">
                  <div class="container-fluid">
                     <div class="row">
                        <div class="col-md-3 page-background">
                           <h1 class="page-title listing-dropdown">
                           	
                           	Notation Types

                           </h1>
                        </div>
                        <div class="col-md-6"></div>
                        <div class="col-md-3" id="header-btn-section">
                          <ul class="new-dropdown-hover">
                            <li class="droupdown-hover-add">
                              <a href="javascript:;" type="button" class="btn btn-info" data-toggle="modal" data-target="#addForm" >New</a>    
                            </li>
                            <!--
                            <li>
                              <button type="button" class="btn" id="header-search-btn"><i class="fa fa-search" aria-hidden="true"></i></button>
                            </li>
                            -->
                          </ul>
                        </div>
                  </div>
               </section>
               <section class="content" id="user-listing-section">
                  
                  <div class="container-fluid">
                     <div class="row">
                        <div class="col-md-12 consumer-section">
                                <div class="messages"></div>
                                <table id="table-general1" class="display user-table" style="width:100%">
                                   <thead>
                                       <tr>
                                           
                                           <th >Title</th>
                                           <th >Action</th>
                                           
                                           
                                       </tr>
                                   </thead>
                                

                                    
                            </table>
                        </div>
                      </div>
                  </div>
               </section>
            </div>
         </div>
          
      </div>
      
      

        <div class="modal fade" id="addForm" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
            <div class="modal-dialog" role="document">
                <div class="modal-content">
                  <div class="modal-header">
                    <h3 class="modal-title" id="exampleModalLabel">Notation Type</h3>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                      <span aria-hidden="true">&times;</span>
                    </button>
                  </div>
                  <div class="modal-body">
                      <div class="form-group">
                        <label for="title">Title</label>
                        <input type="text" class="form-control ntitle" id="title"   placeholder="Enter Title" required>
                      </div>
                  </div>
                  <div class="modal-footer">
                    <button type="button" class="btn btn-primary savedata">Submit</button>
                    <input type="hidden" class="idval"  value="" />
                  </div>
                </div>
            </div>
        </div>
      
        

                                


<?php $__env->stopSection(); ?>

<?php $__env->startSection('script2'); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('end_add_layout'); ?>   
<?php $__env->stopSection(); ?>
<?php $__env->startSection('end_listing_layout'); ?>
    ##parent-placeholder-d2aceb4322da76642ff83281fea16cc279ee4535##

    
        
<script>
    $(document).ready(function() {
        $.ajaxSetup({
          headers: {
              'X-CSRF-TOKEN': $('#csrf_token').val()
          }
        });
        
        
        function renderTable(){
            var oTable = $('#table-general1').dataTable(); 
            oTable.fnDraw(false);
        }
        
        function displayMessage(classname,message){
            var messages = $('.messages');
            var successHtml = '<div class="alert alert-'+ classname +' alert-block">'+
            '<button type="button" class="close" data-dismiss="alert">&times;</button>'+ message +
            '</div>';

            $(messages).html(successHtml);
            setTimeout(function() {
                $('.alert-block').fadeOut('slow');
            }, 4000);
        }
  
       
        
         $('#table-general1').removeAttr('width').DataTable({
             processing: true,
             serverSide: true,
             ajax: {
              url: "<?php echo e(route('getnotationtypes')); ?>",
              type: 'GET',
             },
             columns: [
                         {data: 'title', name: 'title'},
                         {data: 'action', name: 'action', orderable: false, searchable: false},
                   ],
            order: [[0, 'desc']],
            autoWidth: false, 
              columnDefs: [
                  { "width": "700px", "targets": 0 },
                  { "width": "40px", "targets": 1 },

                ],
                

            
          });
          
          $('html').on('click', '.deletedata', function () {
      
                var id = $(this).attr("data");
                
                if(confirm("Are You sure want to delete !")){
                  $.ajax({
                      type: "get",
                      url: "<?php echo e(url('deletenotationtype')); ?>/"+id,
                      success: function (data) {
                            
                                displayMessage(data.class,data.message);
                                renderTable();
                    
                            
                        
                      },
                      error: function (data) {
                          console.log('Error:', data);
                      }
                  });
                }
            });

            $('html').on('click', '.savedata', function () {
      
                var title = $('.ntitle').val();
                var id = $('.idval').val();
                if(id!=''){
                    var dataValues = { title: title,id: id};
                    var url = "<?php echo e(url('notationtypeedit')); ?>";
                }else{
                    var url = "<?php echo e(url('notationtypeadd')); ?>";
                }
                
                if(title==''){
                    $('.ntitle').css('border','1px solid #f00');
                    return false;
                }else{
                
                  $.ajax({
                      url: url,
                      type: "POST",
                      data: dataValues,
                      success: function (data) {
                                $("#addForm").modal('hide');
                                $('.ntitle').val('');
                                $('.idval').val('');
                                displayMessage(data.class,data.message);
                                renderTable();

                      },
                      error: function (data) {
                          console.log('Error:', data);
                      }
                  });
                }
            }); 

            $('html').on('click', '.editdata', function () {
      
                var id = $(this).attr('data');
                $.ajax({
                  url: "<?php echo e(url('notationtypebyid')); ?>/"+id,
                  type: "GET",
                  success: function (data) {
                      
                            if(data.data==0){
                                alert('No record found!!');
                                return false;
                            }else{
                                $('.ntitle').val(data.data.title);
                                $('.idval').val(data.data.id);
                            }
                      

                  },
                  error: function (data) {
                      console.log('Error:', data);
                  }
                });
                
            }); 
            
    
      
    } );
    
    
    
    
    </script>
       <style>
    table#table-general1 tr td,table#table-general1 tr th{padding: 8px;}
    .fade{opacity: 1;}
    .modal-dialog{margin: 15% auto !important;}
    
    </style> 
    
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
    
<?php $__env->stopSection(); ?>
<?php $__env->startSection('end_detail_layout'); ?>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp\www\laravel\laravel8\focuspoint\resources\views/notation/notation-type-listing.blade.php ENDPATH**/ ?>