<?php $__env->startSection('script1'); ?>
       ##parent-placeholder-1e5eb9402f5c726c03e968dbc42e8ac7cd4b5d4b##
<?php $__env->stopSection(); ?>
<?php $__env->startSection('add_layout'); ?>
   
<?php $__env->stopSection(); ?>
<?php $__env->startSection('listing_layout'); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('detail_layout'); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="section">
       
       


    </div>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('script2'); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp\www\laravel\laravel8\focuspoint\resources\views/home.blade.php ENDPATH**/ ?>