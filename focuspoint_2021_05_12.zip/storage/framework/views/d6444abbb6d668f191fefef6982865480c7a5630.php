<?php $__env->startSection('script1'); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('add_layout'); ?>
   ##parent-placeholder-d099313b8b90c924e661041f67c69a99afef7b1e##
<?php $__env->stopSection(); ?>
<?php $__env->startSection('listing_layout'); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('detail_layout'); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
	<?php $__env->startSection('header'); ?>
		##parent-placeholder-594fd1615a341c77829e83ed988f137e1ba96231##
	<?php $__env->stopSection(); ?>

	<?php $__env->startSection('sidebar'); ?>
		##parent-placeholder-19bd1503d9bad449304cc6b4e977b74bac6cc771##
	<?php $__env->stopSection(); ?> 
    
         <div class="content-wrapper">
            <form id="form-consumer" name="employee-form" action="" method="POST">
            <?php echo csrf_field(); ?>
               <div class="background-transperent">
                  <section class="content-header">
                     <div class="container-fluid">
                        <div class="row">
                           <div class="col-md-12 page-background">
                              <h1 class="page-title">Edit Reaction</h1>
                           </div>
                        </div>
                     </div>
                  </section>
                  <section class="content">
                     <div class="container-fluid">
                        <div class="row">
                           <div class="col-md-8 consumer-section">
                              <div class="card card-primary">
                                 <div class="card-body">
            
                                 <div class="form-group row">
                                    <label class="col-md-3 col-form-label">Reaction</label>
                                    <div class="col-md-9">
                                       <div class="row">
                                          <div class="col-md-12 time-add">
                                             <input type="text" name="title" class="form-control "  placeholder="Reaction" value="<?php echo e($reaction->title); ?>" required>
                                          </div>
                                          
                                       </div>                                             
                                    </div>
                                 </div>
                                    
                                 
                                    
                                    
                                    
                             
                                 
                                 </div>
                              </div>
                           </div>
                           <div class="col-md-4">
                           </div>
                        </div>
                     </div>
                  </section>
       
                  
                  <section class="footer-section">
                     <div class="container-fluid">
                        <div class="card-footer">
                           <button type="submit" class="btn btn-info" name="save">Save</button>
                           <a href="<?php echo e(route('reactions')); ?>" class="btn btn-default float-right">Cancel</a>
                         </div>
                     </div>
                  </section>
               </div>
            </form>
         </div>

   

<?php $__env->stopSection(); ?>

<?php $__env->startSection('script2'); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('end_add_layout'); ?>
   ##parent-placeholder-e782a13d7e0722e8ca388effa3e759ed05dd9682##
<?php $__env->stopSection(); ?>
<?php $__env->startSection('end_listing_layout'); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('end_detail_layout'); ?>
<?php $__env->stopSection(); ?>



<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp\www\laravel\laravel8\focuspoint\resources\views/reaction/reaction-edit.blade.php ENDPATH**/ ?>