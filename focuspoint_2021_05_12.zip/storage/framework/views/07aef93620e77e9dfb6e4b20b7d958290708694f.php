<?php $__env->startSection('script1'); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('add_layout'); ?>
   
<?php $__env->stopSection(); ?>
<?php $__env->startSection('listing_layout'); ?>
    ##parent-placeholder-34c9d66d4089e6254c65448001e01f951d92958c##
    <script type="text/javascript">
               $(document).ready(function() {
                   $('#table-general1').DataTable( {

                   "fixedHeader":    true,
                   "bInfo" :         false,
                   "bSortable":      false,
                   searching:        false,
                   paging:           false,
                   fixedColumns: {
                       leftColumns: 1,
                       rightColumns: 1
                   },
                   
                   order: [[ 1, 'asc' ]]
                
                
               });
               //       var  DT1 = $('#table-general').DataTable();
               // $(".selectAll").on( "click", function(e) {
               //     if ($(this).is( ":checked" )) {
               //         DT1.rows(  ).select();        
               //     } else {
               //         DT1.rows(  ).deselect(); 
               //     }
               // });

               } );
         </script>
         
<?php $__env->stopSection(); ?>
<?php $__env->startSection('detail_layout'); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
	<?php $__env->startSection('header'); ?>
		##parent-placeholder-594fd1615a341c77829e83ed988f137e1ba96231##
	<?php $__env->stopSection(); ?>

	<?php $__env->startSection('sidebar'); ?>
		##parent-placeholder-19bd1503d9bad449304cc6b4e977b74bac6cc771##
	<?php $__env->stopSection(); ?> 
    
         <div class="content-wrapper">
            <div class="background-transperent">
               <section class="content-header">
                  <div class="container-fluid">
                     <div class="row">
                        <div class="col-md-3 page-background">
                           <h1 class="page-title listing-dropdown">
                           	
                           	Consumer Note Types

                           </h1>
                        </div>
                        <div class="col-md-6"></div>
                        <div class="col-md-3" id="header-btn-section">
                          <ul class="new-dropdown-hover">
                            <li class="droupdown-hover-add">
                              <a href="<?php echo e(route('consumer-note-type-add')); ?>" class="btn btn-info" id="header-new-btn">New</a>    
                            </li>
                            <!--
                            <li>
                              <button type="button" class="btn" id="header-search-btn"><i class="fa fa-search" aria-hidden="true"></i></button>
                            </li>
                            -->
                          </ul>
                        </div>
                  </div>
               </section>
               <section class="content" id="user-listing-section">
                  <div class="container-fluid">
                     <div class="row">
                        <div class="col-md-12 consumer-section">
                                <table id="table-general1" class="display user-table" style="width:100%">
                                   <thead>
                                       <tr>
                                           
                                           <th>Title</th>
                                           
                                           
                                       </tr>
                                   </thead>
                                <tbody>
                                <?php if(count($consumer_note_types) > 0): ?>
                                    <?php $__currentLoopData = $consumer_note_types; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $consumer_note_type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                        <tr>
                                           
                                            <td><a href="<?php echo e(route('consumer-note-type-edit', $consumer_note_type->id)); ?>" class="name-class"><?php echo e($consumer_note_type->title); ?></a></td>
                                            
                                            
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php else: ?>
                                    <tr>
                                           
                                        <td colspan="2" align="center">No Records!</td>
                                        
                                        
                                    </tr>
                                <?php endif; ?>

                                    
                            </table>
                        </div>
                     </div>
                  </div>
               </section>
            </div>
         </div>
      </div>



<?php $__env->stopSection(); ?>

<?php $__env->startSection('script2'); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('end_add_layout'); ?>   
<?php $__env->stopSection(); ?>
<?php $__env->startSection('end_listing_layout'); ?>
    ##parent-placeholder-d2aceb4322da76642ff83281fea16cc279ee4535##
    <style>
    table#table-general1 tr td,table#table-general1 tr th{padding: 8px;}
    </style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('end_detail_layout'); ?>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp\www\laravel\laravel8\focuspoint\resources\views/consumer_note_type/consumer-note-type-listing.blade.php ENDPATH**/ ?>