@extends('layouts.app')
@section('script1')
       @parent
@endsection
@section('add_layout')
   
@endsection
@section('listing_layout')
@endsection
@section('detail_layout')
@endsection
@section('content')
<div class="section">
       
       


    </div>
@endsection


@section('script2')
@endsection