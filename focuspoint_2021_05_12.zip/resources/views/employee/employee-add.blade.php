@extends('layouts.app')
@section('script1')
<link rel="stylesheet" type="text/css" href="css/jquery-ui-timepicker-addon.css">
      <link rel="stylesheet" type="text/css" href="css/jquery.dataTables.min.css">
      <link rel="stylesheet" type="text/css" href="css/select.dataTables.min.css">
      <link rel="stylesheet" type="text/css" href="css/bootstrap-datetimepicker.css">
      <!-- <script type="text/javascript" src="js/jquery.min.js"></script> -->
      <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/jquery/2.2.0/jquery.min.js"></script>
      <script src="http://code.jquery.com/ui/1.11.0/jquery-ui.js"></script>
      <script type="text/javascript" src="js/jquery.validate.min.js"></script>
      <script type="text/javascript" src="js/app.js"></script>
      <script type="text/javascript" src="js/bootstrap.min.js"></script>
      <script type="text/javascript" src="js/jquery.dataTables.min.js"></script>
@endsection
@section('content')
	@section('header')
		@parent
	@endsection

	@section('sidebar')
		@parent
	@endsection 
    
         <div class="content-wrapper">
            <form id="form-consumer" name="employee-form" action=""  method="post" enctype="multipart/form-data">
            @csrf
               <div class="background-transperent">
                  <section class="content-header">
                     <div class="container-fluid">
                        <div class="row">
                           <div class="col-md-12 page-background">
                              <h1 class="page-title">New Employee</h1>
                           </div>
                        </div>
                     </div>
                  </section>
                  <section class="content">
                     <div class="container-fluid">
                        <div class="row">
                           <div class="col-md-8 consumer-section">
                              <div class="card card-primary">
                                 <div class="card-body">
                                    <div class="form-group row">
                                       <label class="col-md-3 col-form-label">Employee Name</label>
                                       <div class="col-md-9">
                                          <div class="row salutions">
                                             <div class="col-md-3 time-add">
                                                <select class="form-control droupdown mobile-drop" name="salution">
                                                <option value="">Salutation</option>
                                                <option value="Mr">Mr.</option>
                                                <option value="Mrs">Mrs.</option>
                                                <option value="Ms">Ms.</option>
                                                <option value="Miss">Miss.</option>
                                                <option value="Dr">Dr.</option>
                                             </select>                                             
                                             </div>
                                             <div class="col-md-4">
                                                <input type="text" name="fname" class="form-control mobile-drop" placeholder="First Name">
                                             </div>
                                             <div class="col-md-4">
                                                <input type="text" name="lname" class="form-control"  placeholder="Last Name">
                                             </div>
                                          </div>
                                       </div>
                                    </div>
                                    <div class="form-group row">
                                       <label class="col-md-3 col-form-label">Gender</label>
                                       <div class="col-md-9 common-text">
                                          <select class="form-control droupdown width-add" name="gender">
                                             <option value="" selected="selected" disabled="disabled">Select</option>
                                             <option value="Male">Male</option>
                                             <option value="Female">Female</option>
                                          </select>
                                       </div>
                                    </div>
                                    <div class="form-group row">
                                       <label class="col-md-3 col-form-label">Date of Birth</label>
                                       <div class="col-md-9 time-add">
                                          <input type="text" name="dob" class="form-control date-select width-add" id="datetimepicker4" placeholder="mm-dd-yyyy">
                                       </div>
                                    </div>
                                    <div class="form-group row">
                                       <label class="col-md-3 col-form-label">Email Address</label>
                                       <div class="col-md-9 common-text short-col">
                                          <input type="email" name="email" class="form-control width-add"  placeholder="">
                                       </div>
                                    </div>
                                    <div class="form-group row">
                                       <label class="col-md-3 col-form-label">Phone</label>
                                       <div class="col-md-9">
                                          <div class="row">
                                             <div class="col-md-3 time-add">
                                                <input type="tel" name="workphone" class="form-control mobile-drop"  placeholder="Work Phone">
                                             </div>
                                             <div class="col-md-8 time-add">
                                                <input type="tel" name="mobile" class="form-control"  placeholder="Mobile">
                                             </div>
                                          </div>                                             
                                       </div>
                                    </div>
                                    <div class="form-group row">
                                       <label class="col-md-3 col-form-label">Role</label>
                                       <div class="col-md-9 common-text short-col">
                                          <select class="form-control droupdown width-add" name="role_id">
                                             <option value="" selected="selected" disabled="disabled">Select</option>
                                             @foreach ($roles as $role)
                                                <option value="{{$role->id}}">{{$role->role}}</option>
                                             @endforeach
                                          </select>
                                       </div>
                                    </div>
                                    <div class="form-group row">
                                       <label class="col-md-3 col-form-label">Supervisor</label>
                                       <div class="col-md-9 common-text short-col">
                                          <select class="form-control droupdown width-add" name="supervisor">
                                             <option value="" selected="selected" disabled="disabled">Select</option>
                                             <option value="">Supervisor 1</option>
                                             <option value="">Supervisor 2</option>
                                          </select>
                                       </div>
                                    </div>
                                 </div>
                              </div>
                           </div>
                           <div class="col-md-4">
                           </div>
                        </div>
                     </div>
                  </section>
                  <section class="tab-section">
                     <div class="tab-bar">
                        <ul class="nav nav-tabs" id="custom-content-below-tab" role="tablist">
                           <li class="nav-item active">
                            <a class="nav-link tabs active" id="custom-content-below-home-tab" data-toggle="pill" role="tab" aria-controls="custom-content-below-home" aria-selected="false" onclick="openTabs(event, 'services-employee-add')">Services</a>
                          </li>
                          <li class="nav-item">
                            <a class="nav-link tabs" id="custom-content-below-home-tab" data-toggle="pill" role="tab" aria-controls="custom-content-below-home" aria-selected="false" onclick="openTabs(event, 'logins')">Logins</a>
                          </li>
                          <li class="nav-item">
                            <a class="nav-link tabs" id="custom-content-below-profile-tab" data-toggle="pill" role="tab" aria-controls="custom-content-below-profile" aria-selected="false" onclick="openTabs(event, 'address-details')">Address</a>
                          </li>
                          <li class="nav-item">
                            <a class="nav-link tabs" id="custom-content-below-messages-tab" data-toggle="pill" role="tab" aria-controls="custom-content-below-messages" aria-selected="false" onclick="openTabs(event, 'other-details-user')">Other Details</a>
                          </li>
                          <li class="nav-item">
                            <a class="nav-link tabs" id="custom-content-below-settings-tab" data-toggle="pill" role="tab" aria-controls="custom-content-below-settings" aria-selected="true" onclick="openTabs(event, 'contact-persons-user')">Contact Persons</a>
                          </li>
                          <li class="nav-item">
                            <a class="nav-link tabs" id="custom-content-below-settings-tab" data-toggle="pill" role="tab" aria-controls="custom-content-below-settings" aria-selected="true" onclick="openTabs(event, 'certifications')">Certifications</a>
                          </li>
                          <li class="nav-item">
                            <a class="nav-link tabs" id="custom-content-below-settings-tab" data-toggle="pill" role="tab" aria-controls="custom-content-below-settings" aria-selected="true" onclick="openTabs(event, 'documents')">Documents</a>
                          </li>
                        </ul>
                     </div>
                  </section>
                  <section class="contentsection" id="services-employee-add">
                     <div class="container-fluid">
                        <a href="#myModal" class="btn btn-primary add-service" data-toggle="modal">Add New Service</a>
                        <div class="modal fade add-new-services" id="myModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
                           <form id="service-form" action="" name="service-form">
                              <div class="modal-dialog service-dialog">
                                 <div class="modal-content">
                                   <div class="modal-header">
                                     <i class="fa fa-close button-close" data-dismiss="modal" aria-hidden="true"></i>
                                     <h4 class="modal-title">Add New Service</h4>
                                   </div>
                                   <div class="modal-body content-body">
                                       <div class="header-top">
                                          <div class="user-sec">
                                             <div class="user-icons">
                                                <i class="fa fa-user user-icon-client"></i>
                                             </div>
                                             <div class="client-title">
                                                <h2>Client Name</h2>
                                                <h6>Record No.</h6>
                                             </div>
                                          </div>
                                       </div>
                                       <div class="section-service">
                                          <div class="container-fluid">
                                             <div class="row">
                                                <div class="col-md-12">
                                                   <div class="checkbox-parts">
                                                      <input type="checkbox" name="service-90785" class="" value="90785 : Interactive Complexity Add-On">
                                                      <label class="emp-label-add">90785 : Interactive Complexity Add-On</label>
                                                   </div>
                                                   <div class="checkbox-parts">
                                                      <input type="checkbox" name="" class="">
                                                      <label class="emp-label-add">90785 : Interactive Complexity Add-On</label>
                                                   </div>
                                                   <div class="checkbox-parts">
                                                      <input type="checkbox" name="" class="">
                                                      <label class="emp-label-add">90785 : Interactive Complexity Add-On</label>
                                                   </div>
                                                   <div class="checkbox-parts">
                                                      <input type="checkbox" name="" class="">
                                                      <label class="emp-label-add">90785 : Interactive Complexity Add-On</label>
                                                   </div>
                                                   <div class="checkbox-parts">
                                                      <input type="checkbox" name="" class="">
                                                      <label class="emp-label-add">90785 : Interactive Complexity Add-On</label>
                                                   </div>
                                                   <div class="checkbox-parts">
                                                      <input type="checkbox" name="" class="">
                                                      <label class="emp-label-add">90785 : Interactive Complexity Add-On</label>
                                                   </div>
                                                   <div class="checkbox-parts">
                                                      <input type="checkbox" name="" class="">
                                                      <label class="emp-label-add">90785 : Interactive Complexity Add-On</label>
                                                   </div>
                                                   <div class="checkbox-parts">
                                                      <input type="checkbox" name="" class="">
                                                      <label class="emp-label-add">90785 : Interactive Complexity Add-On</label>
                                                   </div>
                                                   <div class="checkbox-parts">
                                                      <input type="checkbox" name="" class="">
                                                      <label class="emp-label-add">90785 : Interactive Complexity Add-On</label>
                                                   </div>
                                                   <div class="checkbox-parts">
                                                      <input type="checkbox" name="" class="">
                                                      <label class="emp-label-add">90785 : Interactive Complexity Add-On</label>
                                                   </div>
                                                   <div class="checkbox-parts">
                                                      <input type="checkbox" name="" class="">
                                                      <label class="emp-label-add">90785 : Interactive Complexity Add-On</label>
                                                   </div>
                                                   <div class="checkbox-parts">
                                                      <input type="checkbox" name="" class="">
                                                      <label class="emp-label-add">90785 : Interactive Complexity Add-On</label>
                                                   </div>
                                                   <div class="checkbox-parts">
                                                      <input type="checkbox" name="" class="">
                                                      <label class="emp-label-add">90785 : Interactive Complexity Add-On</label>
                                                   </div>
                                                   <div class="checkbox-parts">
                                                      <input type="checkbox" name="" class="">
                                                      <label class="emp-label-add">90791 : Clinical Intake (2013)</label>
                                                   </div>
                                                   <div class="checkbox-parts">
                                                      <input type="checkbox" name="" class="">
                                                      <label class="emp-label-add">90791 : Clinical Intake (2013)</label>
                                                   </div>
                                                   <div class="checkbox-parts">
                                                      <input type="checkbox" name="" class="">
                                                      <label class="emp-label-add">90791 : Clinical Intake (2013)</label>
                                                   </div>
                                                   <div class="checkbox-parts">
                                                      <input type="checkbox" name="" class="">
                                                      <label class="emp-label-add">90791 : Clinical Intake (2013)</label>
                                                   </div>
                                                   <div class="checkbox-parts">
                                                      <input type="checkbox" name="" class="">
                                                      <label class="emp-label-add">90791 : Clinical Intake (2013)</label>
                                                   </div>
                                                   <div class="checkbox-parts">
                                                      <input type="checkbox" name="" class="">
                                                      <label class="emp-label-add">90791 : Clinical Intake (2013)</label>
                                                   </div>
                                                   <div class="checkbox-parts">
                                                      <input type="checkbox" name="" class="">
                                                      <label class="emp-label-add">90791 : Clinical Intake (2013)</label>
                                                   </div>
                                                   <div class="checkbox-parts">
                                                      <input type="checkbox" name="" class="">
                                                      <label class="emp-label-add">90791 : Clinical Intake (2013)</label>
                                                   </div>
                                                   <div class="checkbox-parts">
                                                      <input type="checkbox" name="" class="">
                                                      <label class="emp-label-add">90791 : Clinical Intake (2013)</label>
                                                   </div>
                                                   <div class="checkbox-parts">
                                                      <input type="checkbox" name="" class="">
                                                      <label class="emp-label-add">90791 : Clinical Intake (2013)</label>
                                                   </div>
                                                   <div class="checkbox-parts">
                                                      <input type="checkbox" name="" class="">
                                                      <label class="emp-label-add">90791 : Clinical Intake (2013)</label>
                                                   </div>
                                                   <div class="checkbox-parts">
                                                      <input type="checkbox" name="" class="">
                                                      <label class="emp-label-add">90791 : Clinical Intake (2013)</label>
                                                   </div>
                                                   <div class="checkbox-parts">
                                                      <input type="checkbox" name="" class="">
                                                      <label class="emp-label-add">90792 : Psychiatric Diagnostic Evaluation with Med Services</label>
                                                   </div>
                                                   <div class="checkbox-parts">
                                                      <input type="checkbox" name="" class="">
                                                      <label class="emp-label-add">90792 : Psychiatric Diagnostic Evaluation with Med Services</label>
                                                   </div>
                                                   <div class="checkbox-parts">
                                                      <input type="checkbox" name="" class="">
                                                      <label class="emp-label-add">90792 : Psychiatric Diagnostic Evaluation with Med Services</label>
                                                   </div>
                                                   <div class="checkbox-parts">
                                                      <input type="checkbox" name="" class="">
                                                      <label class="emp-label-add">90792 : Psychiatric Diagnostic Evaluation with Med Services</label>
                                                   </div>
                                                   <div class="checkbox-parts">
                                                      <input type="checkbox" name="" class="">
                                                      <label class="emp-label-add">90792 : Psychiatric Diagnostic Evaluation with Med Services</label>
                                                   </div>
                                                   <div class="checkbox-parts">
                                                      <input type="checkbox" name="" class="">
                                                      <label class="emp-label-add">90792 : Psychiatric Diagnostic Evaluation with Med Services</label>
                                                   </div>
                                                   <div class="checkbox-parts">
                                                      <input type="checkbox" name="" class="">
                                                      <label class="emp-label-add">90792 : Psychiatric Diagnostic Evaluation with Med Services</label>
                                                   </div>
                                                </div>
                                             </div>
                                          </div>
                                       </div>
                                   </div>
                                   <div class="modal-footer footer-button">
                                      <button class="btn btn-info add-new-service" data-dismiss="modal">Save</button>
                                      <button class="btn btn-default float-right" data-dismiss="modal">Cancel</button>
                                   </div>
                                 </div>
                              </div>
                           </form>
                        </div>
                        <div class="row">
                           <div class="col-md-4">
                              <div class="checkbox-parts">
                                 <input type="checkbox" name="" class="">
                                 <label class="emp-label-add">90785 : Interactive Complexity Add-On</label>
                              </div>
                              <div class="checkbox-parts">
                                 <input type="checkbox" name="" class="">
                                 <label class="emp-label-add">90785 : Interactive Complexity Add-On</label>
                              </div>
                              <div class="checkbox-parts">
                                 <input type="checkbox" name="" class="">
                                 <label class="emp-label-add">90785 : Interactive Complexity Add-On</label>
                              </div>
                              <div class="checkbox-parts">
                                 <input type="checkbox" name="" class="">
                                 <label class="emp-label-add">90785 : Interactive Complexity Add-On</label>
                              </div>
                              <div class="checkbox-parts">
                                 <input type="checkbox" name="" class="">
                                 <label class="emp-label-add">90785 : Interactive Complexity Add-On</label>
                              </div>
                              <div class="checkbox-parts">
                                 <input type="checkbox" name="" class="">
                                 <label class="emp-label-add">90785 : Interactive Complexity Add-On</label>
                              </div>
                              <div class="checkbox-parts">
                                 <input type="checkbox" name="" class="">
                                 <label class="emp-label-add">90785 : Interactive Complexity Add-On</label>
                              </div>
                              <div class="checkbox-parts">
                                 <input type="checkbox" name="" class="">
                                 <label class="emp-label-add">90785 : Interactive Complexity Add-On</label>
                              </div>
                              <div class="checkbox-parts">
                                 <input type="checkbox" name="" class="">
                                 <label class="emp-label-add">90785 : Interactive Complexity Add-On</label>
                              </div>
                              <div class="checkbox-parts">
                                 <input type="checkbox" name="" class="">
                                 <label class="emp-label-add">90785 : Interactive Complexity Add-On</label>
                              </div>
                              <div class="checkbox-parts">
                                 <input type="checkbox" name="" class="">
                                 <label class="emp-label-add">90785 : Interactive Complexity Add-On</label>
                              </div>
                              <div class="checkbox-parts">
                                 <input type="checkbox" name="" class="">
                                 <label class="emp-label-add">90785 : Interactive Complexity Add-On</label>
                              </div>
                              <div class="checkbox-parts">
                                 <input type="checkbox" name="" class="">
                                 <label class="emp-label-add">90785 : Interactive Complexity Add-On</label>
                              </div>
                           </div>
                           <div class="col-md-4">
                              <div class="checkbox-parts">
                                 <input type="checkbox" name="" class="">
                                 <label class="emp-label-add">90791 : Clinical Intake (2013)</label>
                              </div>
                              <div class="checkbox-parts">
                                 <input type="checkbox" name="" class="">
                                 <label class="emp-label-add">90791 : Clinical Intake (2013)</label>
                              </div>
                              <div class="checkbox-parts">
                                 <input type="checkbox" name="" class="">
                                 <label class="emp-label-add">90791 : Clinical Intake (2013)</label>
                              </div>
                              <div class="checkbox-parts">
                                 <input type="checkbox" name="" class="">
                                 <label class="emp-label-add">90791 : Clinical Intake (2013)</label>
                              </div>
                              <div class="checkbox-parts">
                                 <input type="checkbox" name="" class="">
                                 <label class="emp-label-add">90791 : Clinical Intake (2013)</label>
                              </div>
                              <div class="checkbox-parts">
                                 <input type="checkbox" name="" class="">
                                 <label class="emp-label-add">90791 : Clinical Intake (2013)</label>
                              </div>
                              <div class="checkbox-parts">
                                 <input type="checkbox" name="" class="">
                                 <label class="emp-label-add">90791 : Clinical Intake (2013)</label>
                              </div>
                              <div class="checkbox-parts">
                                 <input type="checkbox" name="" class="">
                                 <label class="emp-label-add">90791 : Clinical Intake (2013)</label>
                              </div>
                              <div class="checkbox-parts">
                                 <input type="checkbox" name="" class="">
                                 <label class="emp-label-add">90791 : Clinical Intake (2013)</label>
                              </div>
                              <div class="checkbox-parts">
                                 <input type="checkbox" name="" class="">
                                 <label class="emp-label-add">90791 : Clinical Intake (2013)</label>
                              </div>
                              <div class="checkbox-parts">
                                 <input type="checkbox" name="" class="">
                                 <label class="emp-label-add">90791 : Clinical Intake (2013)</label>
                              </div>
                              <div class="checkbox-parts">
                                 <input type="checkbox" name="" class="">
                                 <label class="emp-label-add">90791 : Clinical Intake (2013)</label>
                              </div>
                           </div>
                           <div class="col-md-4">
                              <div class="checkbox-parts">
                                 <input type="checkbox" name="" class="">
                                 <label class="emp-label-add">90792 : Psychiatric Diagnostic Evaluation with Med Services</label>
                              </div>
                              <div class="checkbox-parts">
                                 <input type="checkbox" name="" class="">
                                 <label class="emp-label-add">90792 : Psychiatric Diagnostic Evaluation with Med Services</label>
                              </div>
                              <div class="checkbox-parts">
                                 <input type="checkbox" name="" class="">
                                 <label class="emp-label-add">90792 : Psychiatric Diagnostic Evaluation with Med Services</label>
                              </div>
                              <div class="checkbox-parts">
                                 <input type="checkbox" name="" class="">
                                 <label class="emp-label-add">90792 : Psychiatric Diagnostic Evaluation with Med Services</label>
                              </div>
                              <div class="checkbox-parts">
                                 <input type="checkbox" name="" class="">
                                 <label class="emp-label-add">90792 : Psychiatric Diagnostic Evaluation with Med Services</label>
                              </div>
                              <div class="checkbox-parts">
                                 <input type="checkbox" name="" class="">
                                 <label class="emp-label-add">90792 : Psychiatric Diagnostic Evaluation with Med Services</label>
                              </div>
                              <div class="checkbox-parts">
                                 <input type="checkbox" name="" class="">
                                 <label class="emp-label-add">90792 : Psychiatric Diagnostic Evaluation with Med Services</label>
                              </div>
                           </div>
                        </div>
                     </div>
                  </section>
                  <section class="contentsection" id="logins">
                     <div class="container-fluid">
                        <div class="row">
                           <div class="col-md-6">
                              <h5 class="small-sub-title">ADD CREDENTIALS</h5>
                              <div class="card card-primary">
                                 <div class="card-body">
                                    <div class="form-group row">
                                       <label class="col-md-4 col-form-label">Email Address</label>
                                       <div class="col-md-8 common-textbox">
                                          <input type="email" name="emailaddress" class="form-control"  placeholder="">
                                       </div>
                                    </div>
                                    <div class="form-group row">
                                       <label class="col-md-4 col-form-label">Password</label>
                                       <div class="col-md-8 common-textbox">
                                          <input type="password" name="password" id="password" class="form-control"  placeholder="">
                                       </div>
                                    </div>
                                    <div class="form-group row">
                                       <label class="col-md-4 col-form-label">Confirm Password</label>
                                       <div class="col-md-8 common-textbox">
                                          <input name="confirmpassword" type="password" class="form-control"  placeholder="">
                                       </div>
                                    </div>
                                 </div>
                              </div>
                           </div>
                           <div class="col-md-6">
                              <h5 class="small-sub-title">CHANGE PASSWORD</h5>
                              <div class="card card-primary">
                                 <div class="card-body">
                                    <div class="form-group row">
                                       <label class="col-md-4 col-form-label">Old Password</label>
                                       <div class="col-md-8 common-textbox">
                                          <input type="password" name="oldpass" class="form-control"  placeholder="">
                                       </div>
                                    </div>
                                    <div class="form-group row">
                                       <label class="col-md-4 col-form-label">New Password</label>
                                       <div class="col-md-8 common-textbox">
                                          <input type="password" name="newpass" class="form-control"  placeholder="" id="newpassword">
                                       </div>
                                    </div>
                                    <div class="form-group row">
                                       <label class="col-md-4 col-form-label">Confirm Password</label>
                                       <div class="col-md-8 common-textbox">
                                          <input type="password" name="confirmpass" class="form-control"  placeholder="">
                                       </div>
                                    </div>
                                 </div>
                              </div>
                           </div>
                        </div>
                     </div>
                  </section>
                  <section class="contentsection" id="address-details">
                     <div class="container-fluid">
                        <div class="row">
                           <div class="col-md-6">
                              <div class="card card-primary">
                                 <div class="card-body">
                                    <div class="form-group row">
                                       <label class="col-md-4 col-form-label">Address</label>
                                       <div class="col-md-8 common-textbox">
                                          <textarea name="address" class="form-control" placeholder=""></textarea>
                                       </div>
                                    </div>
                                    <div class="form-group row">
                                       <label class="col-md-4 col-form-label required-field"></label>
                                       <div class="col-md-8 common-textbox">
                                          <textarea name="address-1" class="form-control" placeholder=""></textarea>
                                       </div>
                                    </div>
                                    <div class="form-group row">
                                       <label class="col-md-4 col-form-label">City</label>
                                       <div class="col-md-8 common-textbox">
                                          <input type="text" name="city" class="form-control" placeholder="">
                                       </div>
                                    </div>
                                    <div class="form-group row">
                                       <label class="col-md-4 col-form-label">State</label>
                                       <div class="col-md-8 common-textbox">
                                          <select class="form-control droupdown" name="state">
                                             <option value="" selected="selected" disabled="disabled">Select</option>
                                             <option value="">State 1</option>
                                             <option value="">State 2</option>
                                             <option value="">State 3</option>
                                          </select>
                                       </div>
                                    </div>
                                    <div class="form-group row">
                                       <label class="col-md-4 col-form-label">Zip code</label>
                                       <div class="col-md-8 common-textbox">
                                          <input type="text" name="zip-code" class="form-control" placeholder="">
                                       </div>
                                    </div>
                                    <div class="form-group row">
                                       <label class="col-md-4 col-form-label">Country</label>
                                       <div class="col-md-8 common-textbox">
                                          <select class="form-control droupdown" name="country">
                                             <option value="" selected="selected" disabled="disabled">Select</option>
                                             <option value="">Country 1</option>
                                             <option value="">Country 2</option>
                                             <option value="">Country 3</option>
                                          </select>
                                       </div>
                                    </div>
                                 </div>
                              </div>
                           </div>
                        </div>
                     </div>
                  </section>
                  <section class="contentsection" id="other-details-user">
                     <div class="container-fluid">
                        <div class="row">
                           <div class="col-md-6">
                              <div class="card card-primary">
                                 <div class="card-body">
                                    <div class="form-group row">
                                       <label class="col-md-4 col-form-label">Date of Birth</label>
                                       <div class="col-md-8 common-textbox">
                                          <input type="text" name="dob-other" class="form-control date-of-birth" placeholder="">
                                       </div>
                                    </div>
                                    <div class="form-group row">
                                       <label class="col-md-4 col-form-label">SSN</label>
                                       <div class="col-md-8 common-textbox">
                                          <input type="text" name="ssn" class="form-control" placeholder="">
                                       </div>
                                    </div>
                                    <div class="form-group row">
                                       <label class="col-md-4 col-form-label">Hire Date</label>
                                       <div class="col-md-8 common-textbox">
                                          <input type="text" name="hire-date" class="form-control hire-date" placeholder="">
                                       </div>
                                    </div>
                                    <div class="form-group row">
                                       <label class="col-md-4 col-form-label">Termination Date</label>
                                       <div class="col-md-8 common-textbox">
                                          <input type="text" name="hire-date" class="form-control termination-date" placeholder="">
                                       </div>
                                    </div>
                                    <div class="form-group row">
                                       <label class="col-md-4 col-form-label">Qualification</label>
                                       <div class="col-md-8 common-textbox">
                                          <select id="multiple-checkboxes" multiple="multiple">
                                             <option value="QMHP-A">QMHP-A</option>
                                             <option value="QMHP-C">QMHP-C</option>
                                             <option value="QMHP-T">QMHP-T</option>
                                             <option value="LPC">LPC</option>
                                             <option value="LPC-R">LPC-R</option>
                                             <option value="LMHP-S">LMHP-S</option>
                                             <option value="LMHP">LMHP</option>
                                             <option value="LCAS">LCAS</option>
                                             <option value="LCAS-R">LCAS-R</option>
                                          </select> 
                                       </div>
                                    </div>
                                    <div class="form-group row">
                                       <label class="col-md-4 col-form-label">NPI #</label>
                                       <div class="col-md-8 common-textbox">
                                          <input type="text" name="npi" class="form-control" placeholder="">
                                       </div>
                                    </div>
                                    <div class="form-group row">
                                       <label class="col-md-4 col-form-label">Taxonomy #</label>
                                       <div class="col-md-8 common-textbox">
                                          <input type="text" name="taxonomy" class="form-control" placeholder="">
                                       </div>
                                    </div>
                                    <div class="form-group row">
                                       <label class="col-md-4 col-form-label">Background Check</label>
                                       <div class="col-md-8 common-textbox">
                                          <input type="text" name="back-check" class="form-control" placeholder="">
                                       </div>
                                    </div>
                                    <div class="form-group row">
                                       <label class="col-md-4 col-form-label">Last TB Shot</label>
                                       <div class="col-md-8 common-textbox">
                                          <input type="text" name="last-shot" class="form-control" placeholder="">
                                       </div>
                                    </div>
                                    <div class="form-group row">
                                       <label class="col-md-4 col-form-label">DL #</label>
                                       <div class="col-md-8 common-textbox">
                                          <input type="text" name="dl" class="form-control" placeholder="">
                                       </div>
                                    </div>
                                    <div class="form-group row">
                                       <label class="col-md-4 col-form-label">DL Expiration</label>
                                       <div class="col-md-8 common-textbox">
                                          <input type="text" name="dl-expiration" class="form-control" placeholder="">
                                       </div>
                                    </div>
                                    <div class="form-group row">
                                       <label class="col-md-4 col-form-label">DL State</label>
                                       <div class="col-md-8 common-textbox">
                                          <input type="text" name="dl-state" class="form-control" placeholder="">
                                       </div>
                                    </div>                                    
                                 </div>
                              </div>
                           </div>
                        </div>
                     </div>
                  </section>
                  <section class="contentsection" id="contact-persons-user">
                     <div class="container-fluid">
                        <div class="row">
                           <div class="col-md-12">
                              <div class="table-scrollbar">
                                 <table class="table-contact-user common-table-info">
                                    <thead>
                                     <tr>
                                       <th>Contact Type</th>
                                       <th>First Name</th>
                                       <th>Last Name</th>
                                       <th>Relationship</th>
                                       <th>Phone</th>
                                       <th>Mobile</th>
                                       <th>Email Address</th>
                                       <th>Address 1</th>
                                       <th>Address 2</th>
                                       <th>City</th>
                                       <th>State</th>
                                       <th>Country</th>
                                     </tr>
                                    </thead>
                                    <tbody>
                                       <tr class="tr-contact-person common-tr-info">
                                          <td>
                                             <select class="form-control droupdown custom-contact-field common-text-box-new" name="contact-type">
                                                <option value="" selected="selected" disabled="disabled">Select</option>
                                                <option value="mr">Mr.</option>
                                                <option value="mrs">Mrs.</option>
                                                <option value="ms">Ms.</option>
                                                <option value="miss">Miss.</option>
                                                <option value="dr">Dr.</option>
                                             </select>
                                          </td>
                                          <td>
                                             <input type="text" name="first-name" class="form-control custom-contact-field common-text-box-new" placeholder="">
                                          </td>
                                          <td>
                                             <input type="text" name="last-name" class="form-control custom-contact-field common-text-box-new" placeholder="">
                                          </td>
                                          <td>
                                             <select class="form-control droupdown custom-contact-field common-text-box-new" name="relationship">
                                                <option value="" selected="selected" disabled="disabled">Select</option>
                                                <option value="">Select 1</option>
                                                <option value="">Select 2</option>
                                             </select>
                                          </td>
                                          <td>
                                             <input type="text" name="phone" class="form-control custom-contact-field common-text-box-new" placeholder="">
                                          </td>
                                          <td>
                                             <input type="text" name="mobile" class="form-control custom-contact-field common-text-box-new" placeholder="">
                                          </td>
                                          <td>
                                             <input type="email" name="emailperson" class="form-control custom-contact-field common-text-box-new" placeholder="">
                                          </td>
                                          <td>
                                             <input type="text" name="address-1" class="form-control custom-contact-field common-text-box-new" placeholder="">
                                          </td>
                                          <td>
                                             <input type="text" name="address-2" class="form-control custom-contact-field common-text-box-new" placeholder="">
                                          </td>
                                          <td>
                                             <input type="text" name="city" class="form-control custom-contact-field common-text-box-new" placeholder="">
                                          </td>
                                          <td>
                                             <select class="form-control droupdown custom-contact-field common-text-box-new" name="state">
                                                <option value="" selected="selected" disabled="disabled">Select</option>
                                                <option value="">Gujarat</option>
                                                <option value="">Rajasthan</option>
                                             </select>
                                          </td>
                                          <td>
                                             <select class="form-control droupdown custom-contact-field common-text-box-new" name="country">
                                                <option value="" selected="selected" disabled="disabled">Select</option>
                                                <option value="">India</option>
                                                <option value="">UK</option>
                                             </select>
                                          </td>
                                       </tr>
                                    </tbody>
                                 </table>
                              </div>
                              <button class="add_form_contact_user common-button"><i class="fa fa-plus common-icons"></i>Add New Contact</button> 
                           </div>
                        </div>
                     </div>
                  </section>
                  <section class="contentsection" id="certifications">
                     <div class="container-fluid">
                        <div class="row">
                           <div class="col-md-12">
                              <div class="table-scrollbar common-scroll">
                                 <table class="table-contact-certification common-table-info">
                                    <thead>
                                     <tr>
                                       <th>Certification</th>
                                       <th>Received Date</th>
                                       <th>Expiry Date</th>
                                     </tr>
                                    </thead>
                                    <tbody>
                                       <tr class="tr-certification-person common-tr-info">
                                          <td>
                                             <select class="form-control droupdown custom-contact-field common-text-box-new" name="certification">
                                                <option value="" selected="selected" disabled="disabled">Select</option>
                                                <option value="">Select 1</option>
                                                <option value="">Select 2</option>
                                             </select>
                                          </td>
                                          <td>
                                             <input type="text" name="received-date" class="form-control custom-contact-field received-date common-text-box-new" placeholder="">
                                          </td>
                                          <td>
                                             <input type="text" name="expiry-date" class="form-control custom-contact-field expiry-date common-text-box-new" placeholder="">
                                          </td>
                                       </tr>
                                    </tbody>
                                 </table>
                              </div>                              
                              <button class="add_form_certification common-button"><i class="fa fa-plus common-icons"></i>Add New Certification</button> 
                           </div>
                        </div>
                     </div>
                  </section>
                  <section class="contentsection" id="documents">
                     <div class="container-fluid">
                        <div class="row">
                           <div class="col-md-7">
                              <div class="card-body">
                                 <div class="form-group row">
                                    <div class="col-md-6">
                                       <label class="attach-file-lbl attach-file-label">Attach Files</label>
                                       <div class="file-upload-multiple">
                                          <label class="lbl-multiple-files">Select Multiple Files</label>
                                          <input type="file" name="filenames[]" class="form-control multiple-image-upload" id="file-upload" multiple="">
                                       </div>
                                    </div>
                                    <div class="col-md-6">
                                       <div id="uploadPreview" class="employee-image"></div>
                                    </div>
                                 </div>
                              </div>   
                           </div>
                           <div class="col-md-5"></div>
                        </div>
                     </div>
                  </section>
                  <section class="footer-section">
                     <div class="container-fluid">
                        <div class="card-footer">
                           <button type="submit" class="btn btn-info">Save</button>
                           <a href="{{ route('employee-listing') }}" class="btn btn-default float-right">Cancel</a>
                         </div>
                     </div>
                  </section>
               </div>
            </form>
         </div>

   

@endsection
@section('script2')
<script src="https://trentrichardson.com/examples/timepicker/jquery-ui-timepicker-addon.js"></script>
<script type="text/javascript" src="js/moment.min.js"></script>
<script type="text/javascript" src="js/angular.min.js"></script>
<script type="text/javascript" src="js/bootstrap-datetimepicker.min.js"></script>
<script type="text/javascript">
   $('.nav-sidebar').on('click', 'li', function() {
     $('.nav-sidebar li.active-menu').removeClass('active-menu');
     $(this).addClass('active-menu');
   });
</script>
<script type="text/javascript">
   $(document).ready(function() {
       $('.date-select').datepicker({ format: "mm/dd/yyyy" });
   }); 
   $(document).ready(function() {
       $('.diagnosis-date').datepicker({ format: "mm/dd/yyyy" });
   }); 
   $(document).ready(function() {
       $('.date-type').datepicker({ format: "mm/dd/yyyy" });
   }); 


   // Scroolbar scroll
   var $hs = $('.table-scrollbar');
   var $sLeft = 0;
   var $hsw = $hs.outerWidth(true);
   $( window ).resize(function() {
     $hsw = $hs.outerWidth(true);
   });
   function scrollMap($sLeft) {
     $hs.scrollLeft($sLeft);
   }
   $hs.on('mousewheel', function(e) {
     var $max = $hsw * 2 + (-e.originalEvent.wheelDeltaY);
     if ($sLeft > -1){
       $sLeft = $sLeft + (-e.originalEvent.wheelDeltaY);
     } else {
       $sLeft = 0;
     }
     if ($sLeft > $max) {
       $sLeft = $max;
     }
     if(($sLeft > 0) && ($sLeft < $max)) {
       e.preventDefault();
       e.stopPropagation(); 
     }
     scrollMap($sLeft);
   });

   $('#user-add-icon').click(function(){
      $("#drop-down-profile").toggleClass('show');
   });

    $('#user-mobile-icon').click(function(){
      $("#mobile-dropdown").toggleClass('show-add');
   });
   
   $("#spent-time-add").timepicker();


// Spent Time Add
$(document).ready(function() {
   $('.start-date').datepicker({ format: "mm/dd/yyyy" });
});
$(document).ready(function() {
   $('.end-date').datepicker({ format: "mm/dd/yyyy" });
});
$("#start-time").timepicker();
$("#end-time").timepicker(); 
</script>

<script type="text/javascript">
$(function() {
  $("form[name='assessment-form']").validate({
    rules: {
      consumername: "required",
      payername: "required",
      assessmenttype: "required"
    },
    messages: {
      consumername: "Please enter your Consumer Name",
      payername: "Please enter your Payer Name",
      assessmenttype: "Please enter your Type"
    },
    submitHandler: function(form) {
      form.submit();
    }
  });
});

// Images Preview JS
function readImage(file) {
  var reader = new FileReader();
  var image  = new Image();

  reader.readAsDataURL(file);  
  reader.onload = function(_file) {
    image.src = _file.target.result;
    image.onload = function() {
      var n = file.name;
      $('#uploadPreview').append('<div class="image-section"><div class="row"><div class="col-md-8"><p class="file-name-image">' + n + '</p></div><div class="col-md-4"><span class="delete-image"><i class="fa fa-trash delete" aria-hidden="true"></i>Delete</span></div></div></div>');
      $('.delete-image').click(function(){
        $(this).parent().parent().parent().remove();
      });
    };

    image.onerror= function() {
      alert('Invalid file type: '+ file.type);
    };    
  };
}
$("#file-upload").change(function (e) {
  if(this.disabled) {
    return alert('File upload not supported!');
  }
  var F = this.files;
  if (F && F[0]) {
    for (var i = 0; i < F.length; i++) {
      readImage(F[i]);
    }
  }
});

$('.common-selectbox').click(function(){
   $('.common-selectbox').toggleClass('add-down-arrow-show');
});

// Date and Time Picker
$(function () {
   $('#startdatetimepicker').datetimepicker({ 
      allowInputToggle: true,
      format: 'YYYY-MMM-DD HH:mm',
      inline: false,
      sideBySide: true
   }); 
});
$(function () {
   $('#enddatetimepicker').datetimepicker({ 
      allowInputToggle: true,
      format: 'YYYY-MMM-DD HH:mm',
      inline: false,
      sideBySide: true
   }); 
});
</script>


@endsection
